set -e
export TORCH_DEVICE_BACKEND_AUTOLOAD=0
source /opt/ascend/cann-9.2.0/set_env.sh
source /usr/local/Ascend/nnal/atb/set_env.sh
set -u
export PYTHONPATH=/work/source-layer0-v1${PYTHONPATH:+:$PYTHONPATH}
export LD_LIBRARY_PATH=/opt/openEuler/gcc-toolset-12/root/usr/lib64${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}
export PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=8 MKL_NUM_THREADS=8
export ASCEND_CACHE_PATH=/work/evidence/prefix-values-unit-v1-cache/ascend
set +e
timeout 600 /work/tools/strace/usr/bin/strace --seccomp-bpf -f -e trace=openat -o /work/receipts/prefix-values-unit-v1-strace.log python -B /work/receipts/prefix-values-device-v1/check_device.py --fixture /prefix-values/layer0-expanded-first-difference.pt --bank /prefix-values/output/rank-2.pt --bank-receipt /prefix-values/output/rank-2.json --original /work/receipts/resident-device-v1/expanded_attention.py --cached /work/receipts/prefix-values-device-v1/attention.py --output /work/evidence/prefix-values-unit-v1.json > /work/receipts/prefix-values-unit-v1-driver.log 2>&1
status=$?
echo "$status" > /work/receipts/prefix-values-unit-v1-exit.txt
exit "$status"
