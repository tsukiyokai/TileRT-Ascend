"""Inspect only Value coordinates where the frozen CPU and A3 disagree."""

import hashlib
import json
from pathlib import Path

import torch


root = Path('/work')
fixture_path = root / 'inputs/layer0-expanded-first-difference.pt'
outputs_path = root / 'evidence/layer0-expanded-unit-v1/outputs.pt'
fixture = torch.load(fixture_path, map_location='cpu', weights_only=True)
actual = torch.load(outputs_path, map_location='cpu', weights_only=True)
torch.set_num_threads(8)
inputs = fixture['inputs']
position = torch.arange(8193)
physical = inputs['block_table'][0].long()[position // 128] * 128 + position % 128
latent = inputs['key_cache'].view(-1, 512)[physical]
uv = fixture['weights']['uv']
report = {'scope': 'FP64 control on the union of observed Value disagreements only', 'precision_verified': False, 'performance_measured': False, 'groups': {}}
replaced = {}
for name, offset in [('value_prefix', 0), ('value_current', 8192)]:
    cpu = fixture['cpu'][name]
    bf16, fp32 = actual['bf16'][name], actual['fp32'][name]
    indices = torch.nonzero((cpu != bf16) | (cpu != fp32))
    h, row, column = indices.unbind(-1)
    high_precision = (latent[row + offset].double() * uv.permute(0, 2, 1)[h, column].double()).sum(-1)
    rounded = high_precision.bfloat16()
    cpu_selected, bf16_selected, fp32_selected = cpu[h, row, column], bf16[h, row, column], fp32[h, row, column]
    changed = cpu_selected != bf16_selected
    midpoint = (cpu_selected.double() + bf16_selected.double()) / 2
    report['groups'][name] = {
        'coordinates_examined': len(indices),
        'cpu_matches_fp64_rounding': int((cpu_selected == rounded).sum()),
        'bf16_bmm_matches_fp64_rounding': int((bf16_selected == rounded).sum()),
        'fp32_bmm_matches_fp64_rounding': int((fp32_selected == rounded).sum()),
        'cpu_bf16_disagreements': int(changed.sum()),
        'exact_midpoints_among_cpu_bf16_disagreements': int(((high_precision == midpoint) & changed).sum()),
    }
    replaced[name] = cpu.clone()
    replaced[name][h, row, column] = rounded
with torch.backends.mkldnn.flags(enabled=False, deterministic=None, allow_tf32=None, fp32_precision=None):
    probabilities = fixture['cpu']['aligned_probability'].unsqueeze(1)
    outcomes = {}
    for label, values in [('cpu', fixture['cpu']), ('device_bf16_value', actual['bf16']), ('device_fp32_value', actual['fp32']), ('fp64_corrected_disagreements', replaced)]:
        pv = torch.matmul(probabilities, torch.cat((values['value_prefix'], values['value_current']), dim=1)).transpose(0, 1)
        outcomes[label] = {'matches_original_cpu_pv': torch.equal(pv, fixture['cpu']['pv']), 'matches_original_device_pv': torch.equal(pv, fixture['full_npu']['pv']), 'unequal_to_original_cpu': int((pv != fixture['cpu']['pv']).sum()), 'pv_sha256': hashlib.sha256(pv.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()}
    assert outcomes['cpu']['matches_original_cpu_pv']
report['cpu_pv_interventions'] = outcomes
report['fixture_sha256'] = hashlib.sha256(fixture_path.read_bytes()).hexdigest()
report['device_outputs_sha256'] = hashlib.sha256(outputs_path.read_bytes()).hexdigest()
(root / 'evidence/layer0-expanded-fp64.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
