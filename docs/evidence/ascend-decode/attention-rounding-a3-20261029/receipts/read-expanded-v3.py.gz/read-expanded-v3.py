"""Check the changed A3 layer against unchanged HF and CANN controls."""

import hashlib
import json
from pathlib import Path
import sys

import torch

sys.path.insert(0, '/work/source-layer0-v1/tests/glm52')
from check_mla import metrics


root = Path('/work')
folder = root / 'evidence/layer0-expanded-v1'
control = root / 'evidence/layer0-boundaries-v4'
hf_path = root / 'hub/trt-a3-reference-20261028-2205/complete/step-08192.pt'
hf_manifest = json.loads((hf_path.parent / 'manifest.json').read_text())
hf_sha = hashlib.sha256(hf_path.read_bytes()).hexdigest()
assert hf_sha == hf_manifest['trace_sha256'][hf_path.name]
hf = torch.load(hf_path, map_location='cpu', weights_only=True, mmap=True)
summary = json.loads((folder / 'summary.json').read_text())
assert len(summary['ranks']) == 16
rows, values, attention_inputs = [], [], []
for rank in range(16):
    report_path = folder / f'rank-{rank}.json'
    report = json.loads(report_path.read_text())
    assert report['checkpoint_sha256'] == hf_manifest['metadata_sha256']
    sha = hashlib.sha256(report_path.read_bytes()).hexdigest()
    assert sha == next(row['report_sha256'] for row in summary['ranks'] if row['rank'] == rank)
    path = folder / f'rank-{rank}/layer-00.pt'
    raw_sha = hashlib.sha256(path.read_bytes()).hexdigest()
    assert list(report['artifact_sha256'].values()) == [raw_sha]
    data = torch.load(path, map_location='cpu', weights_only=True, mmap=True)
    old = torch.load(control / f'rank-{rank}/layer-00.pt', map_location='cpu', weights_only=True, mmap=True)
    bad = [item['name'] for item in report['checks'] if not item['passed']]
    assert set(bad) <= {'layer0.token0.merged'}, bad
    b = data['boundaries']
    assert tuple(b['sfa.output'].shape) == (1, 4, 256)
    assert torch.equal(b['sfa.output'].reshape(1, 1024), b['o_proj.input'])
    unchanged = {name: torch.equal(b[name], old['boundaries'][name]) for name in ['input_norm', 'sfa.query_nope', 'sfa.query_rope', 'sfa.indices', 'sfa.block_table', 'sfa.query_lengths', 'sfa.key_lengths']}
    positions = torch.arange(8193)
    for name, width in [('key_cache', 512), ('rope_cache', 64)]:
        page = b['sfa.block_table'][0].long()[positions // 128]
        old_page = old['boundaries']['sfa.block_table'][0].long()[positions // 128]
        left = b['sfa.' + name][page, positions % 128, 0]
        right = old['boundaries']['sfa.' + name][old_page, positions % 128, 0]
        unchanged['valid_' + name] = torch.equal(left, right)
    assert all(unchanged.values()), unchanged
    assert torch.equal(data['input_hidden'], hf['hidden_states'][0])
    detail = metrics(data['merged'], hf['hidden_states'][1])
    rows.append({'rank': rank, 'capture_sha256': raw_sha, 'report_sha256': sha,
                 'original_cann_comparison_failures': bad, 'input_controls_unchanged': unchanged,
                 'h1_vs_hf': {'exact': torch.equal(data['merged'], hf['hidden_states'][1]), **detail},
                 'h1_vs_original_cann': metrics(data['merged'], old['merged']),
                 'attention_source': data['boundary_metadata']['sfa']})
    values.append(data['merged'])
    attention_inputs.append(b['o_proj.input'])
assert 'torch_npu' not in __import__('sys').modules
joined = torch.cat(attention_inputs, dim=-1).contiguous()
attention_sha = hashlib.sha256(joined.view(torch.uint8).numpy().tobytes()).hexdigest()
cpu_candidate = json.loads((root / 'evidence/layer0-tail-v8.json').read_text())
expected_sha = cpu_candidate['sfa']['expanded_value']['bf16_score_probability']['o_proj_input_sha256']
report = {'status': 'capture_checked', 'scope': 'Actual A3 TP16 first-layer M1 only',
          'o_proj_inputs_sha256': attention_sha,
          'cpu_candidate_o_proj_inputs_sha256': expected_sha,
          'o_proj_inputs_match_cpu_candidate': attention_sha == expected_sha,
          'hf_step_sha256': hf_sha,
          'rank_agreement': all(torch.equal(values[0], value) for value in values),
          'local_h1_exact_ranks': sum(row['h1_vs_hf']['exact'] for row in rows),
          'local_h1_nrmse_max': max(row['h1_vs_hf']['nrmse'] for row in rows),
          'capture_summary_status': summary['status'], 'ranks': rows,
          'precision_verified': False, 'formal_precision_gate_passed': False,
          'performance_measured': False, 'thresholds_modified': False,
          'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
output = root / 'evidence/layer0-expanded-v1-detail.json'
output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k != 'ranks'}))
