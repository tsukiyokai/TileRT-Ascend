"""Read three actual A3 layers against the unchanged frozen HF frame."""

import hashlib
import json
from pathlib import Path
import sys

import torch

sys.path.insert(0, "/work/source-layer0-v1/tests/glm52")
from check_mla import metrics


ROOT = Path("/work")
FOLDER = ROOT / "evidence/first3-expanded-192-v1"
HF = ROOT / "hub/trt-a3-reference-20261028-2205/complete"
HELPER_SHA = "50e2a19d621ee65d0700a20f38284a3ad83357ff090967e2ae755de500020a00"


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024**2), b""):
            value.update(block)
    return value.hexdigest()


def main():
    torch.set_num_threads(8)
    manifest = json.loads((HF / "manifest.json").read_text())
    frame_path = HF / "step-08192.pt"
    frame_sha = digest(frame_path)
    assert frame_sha == manifest["trace_sha256"][frame_path.name]
    frame = torch.load(
        frame_path, map_location="cpu", weights_only=True, mmap=True
    )
    summary = json.loads((FOLDER / "summary.json").read_text())
    assert sorted(row["rank"] for row in summary["ranks"]) == list(range(16))
    layers = {number: [] for number in range(3)}
    ranks = []
    for rank in range(16):
        report_path = FOLDER / f"rank-{rank}.json"
        report = json.loads(report_path.read_text())
        bound = next(row for row in summary["ranks"] if row["rank"] == rank)
        assert digest(report_path) == bound["report_sha256"]
        assert report["checkpoint_sha256"] == manifest["metadata_sha256"]
        assert (report["layers"], report["steps"], report["query_width"]) == (
            3, 1, 1
        )
        comparison_names = {
            f"layer{number}.token0.{name}"
            for number in range(3)
            for name in ("input_merged", "merged", "latent", "rope", "indices",
                         "index_keys", "index_scales")
        }
        failed = [row["name"] for row in report["checks"] if not row["passed"]]
        unexpected = sorted(set(failed) - comparison_names)
        artifacts = report["artifact_sha256"]
        assert len(artifacts) == 3
        details = []
        previous = None
        for number in range(3):
            path = FOLDER / f"rank-{rank}/layer-{number:02d}.pt"
            raw_sha = digest(path)
            expected = [
                sha for name, sha in artifacts.items()
                if Path(name).parts[-2:] == path.parts[-2:]
            ]
            assert expected == [raw_sha]
            data = torch.load(
                path, map_location="cpu", weights_only=True, mmap=True
            )
            assert data["rank"] == rank and data["layer"] == number
            assert data["positions"] == [8192]
            assert data["boundary_metadata"]["sfa"]["source_sha256"] == HELPER_SHA
            if previous is not None:
                assert torch.equal(data["input_merged"], previous)
            else:
                assert torch.equal(data["input_merged"], frame["hidden_states"][0])
            actual = data["merged"]
            value = metrics(actual, frame["hidden_states"][number + 1])
            details.append({
                "layer": number,
                "artifact_sha256": raw_sha,
                "h_vs_hf": value,
                "within_existing_hidden_tolerance": (
                    value["finite"] and value["nrmse"] <= 0.01
                    and value["cosine"] >= 0.999
                ),
            })
            layers[number].append(actual.clone())
            previous = actual
        ranks.append({
            "rank": rank,
            "report_sha256": digest(report_path),
            "checks": len(report["checks"]),
            "original_cann_comparison_failures": failed,
            "unexpected_failures": unexpected,
            "layers": details,
        })
    agreement = {
        number: all(torch.equal(values[0], item) for item in values)
        for number, values in layers.items()
    }
    worst = {
        number: max(row["layers"][number]["h_vs_hf"]["nrmse"] for row in ranks)
        for number in range(3)
    }
    output = {
        "scope": "Actual A3 TP16 first three layers, M1, one frozen 8K input",
        "status": "capture_checked",
        "hf_frame_sha256": frame_sha,
        "helper_sha256": HELPER_SHA,
        "capture_summary_status": summary["status"],
        "rank_agreement": agreement,
        "worst_hidden_nrmse": worst,
        "h3_prediction": {"threshold": 0.0054, "met": worst[2] < 0.0054},
        "structural_checks_passed": not any(
            row["unexpected_failures"] for row in ranks
        ),
        "all_three_within_existing_hidden_tolerance": all(
            layer["within_existing_hidden_tolerance"]
            for row in ranks for layer in row["layers"]
        ),
        "ranks": ranks,
        "formal_precision_gate_passed": False,
        "performance_measured": False,
        "thresholds_modified": False,
        "script_sha256": digest(Path(__file__)),
    }
    (ROOT / "evidence/first3-expanded-192-v1-check-v2.json").write_text(
        json.dumps(output, indent=2) + "\n"
    )
    print(json.dumps({key: value for key, value in output.items() if key != "ranks"}))
    return 0 if output["structural_checks_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
