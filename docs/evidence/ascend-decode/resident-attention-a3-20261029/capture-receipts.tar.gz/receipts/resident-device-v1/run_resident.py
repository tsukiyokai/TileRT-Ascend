"""Capture one real resident TP16 M1 frame and its exact reset."""

import argparse
import hashlib
import importlib
import inspect
import json
import os
import sys
from pathlib import Path
from unittest.mock import patch


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def capture_routes(original, install, engine, *args, **kwargs):
    restorers, samples = [], {}
    try:
        for number, layer in enumerate(engine.model.model.layers[3:], start=3):
            samples[number] = []
            restorers.append(install(layer, samples[number]))
        result = original(engine, *args, **kwargs)
    finally:
        for restore in reversed(restorers):
            restore()
        restorers.clear()
    receipts = {}
    for number, rows in samples.items():
        if len(rows) != 1:
            raise ValueError(f"Expected one actual route for layer {number}")
        row = rows[0]
        receipts[number] = {
            "metadata": row["metadata"],
            **{
                name: row[name].cpu().clone()
                for name in ("ids", "weights", "router_logits")
            },
        }
    result["routing_receipts"] = receipts
    return result


def capture_expanded(engine, args, legacy, install, restore, sources):
    import torch
    from run_native_decode import compare_tensor
    from torch import distributed
    from vllm.distributed import get_world_group

    parent_path = args.output / f"rank-{engine.rank}.json"
    parent = json.loads(parent_path.read_text())
    prefixes, _, inputs = legacy.load_capture(
        args.capture_case, engine.rank, parent["checkpoint_sha256"]
    )
    assert inputs == parent["inputs"]
    reference_path = args.reference / "step-08192.pt"
    manifest = json.loads((args.reference / "manifest.json").read_text())
    assert (
        legacy.digest(reference_path)
        == manifest["trace_sha256"][reference_path.name]
    )
    expected = torch.load(
        reference_path, map_location="cpu", weights_only=True
    )
    output = args.output.parent / "expanded"
    directory = output / f"rank-{engine.rank}"
    directory.mkdir(parents=True, exist_ok=False)
    for layer in engine.model.model.layers:
        impl = layer.self_attn.mla_attn.mla_attn.impl
        restore.append(install(impl))

    def prepare():
        engine.reset()
        assert engine.position == 0
        engine.storage.zero_()
        engine.inject(prefixes)
        assert engine.position == 8192

    def capture():
        return legacy.capture_step(
            engine,
            expected["token"],
            8192,
            True,
            mlp_layer=args.trace_mlp_layer,
        )

    prepare()
    actual = capture()
    path = directory / "step-08192.pt"
    with path.open("xb") as stream:
        torch.save(actual, stream)
    checks, hf_checks = [], []
    compare_tensor(
        "ids_vs_actual_logits",
        actual["token_ids"],
        actual["logits"].argmax(-1),
        checks,
        exact=True,
    )
    legacy.check_prefix(engine, prefixes, checks, "decode")
    legacy.compare_step("hf.0", actual, expected, hf_checks)
    prepare()
    repeated = capture()
    reset_path = directory / "reset-step-08192.pt"
    with reset_path.open("xb") as stream:
        torch.save(repeated, stream)
    legacy.compare_step("reset.0", repeated, actual, checks, exact=True)
    legacy.check_prefix(engine, prefixes, checks, "reset")
    passed = all(row["passed"] for row in checks)
    report = {
        **parent,
        "scope": "Same resident TP16 model, expanded attention M1 and exact reset",
        "status": "captured" if passed else "fail",
        "recipe": "expanded",
        "parent_control_report_sha256": legacy.digest(parent_path),
        "source_sha256": {
            **engine.source_metadata(),
            **sources,
            **actual["choice_source_sha256"],
        },
        "trace_sha256": {path.name: legacy.digest(path)},
        "reset_trace_sha256": {reset_path.name: legacy.digest(reset_path)},
        "checks": checks,
        "diagnostics": [],
        "hf_strict_checks": hf_checks,
        "hf_strict_checks_passed": all(row["passed"] for row in hf_checks),
        "repeatability_passed": passed,
        "predicted_tokens": actual["token_ids"].tolist(),
        "hf_diagnostics_complete": True,
        "formal_precision_gate_passed": False,
        "performance_measured": False,
        "recipe_comparison": "Same model and world, restored KV; caches shared; no timing claim",
    }
    report_path = output / f"rank-{engine.rank}.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    ranks = [None] * 16
    distributed.all_gather_object(
        ranks,
        {
            "rank": engine.rank,
            "passed": passed,
            "hf_strict_checks_passed": report["hf_strict_checks_passed"],
            "predicted_tokens": report["predicted_tokens"],
            "report_sha256": legacy.digest(report_path),
        },
        group=get_world_group().cpu_group,
    )
    if engine.rank == 0:
        summary = {
            "status": "captured"
            if all(row["passed"] for row in ranks)
            else "fail",
            "ranks": ranks,
            "precision_verified": False,
            "formal_precision_gate_passed": False,
            "performance_measured": False,
            "scope": report["scope"],
        }
        (output / "summary.json").write_text(
            json.dumps(summary, indent=2) + "\n"
        )
        print(json.dumps(summary))


def main():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--check-inputs-only", action="store_true")
    parser.add_argument(
        "--recipe", choices=("control", "expanded", "paired"), required=True
    )
    options, remaining = parser.parse_known_args()
    sys.path[:0] = [str(options.source), str(options.source / "tests/glm52")]
    legacy = importlib.import_module("run_cann_model")
    from expanded_attention import install
    from routes import install_routes

    with patch.object(sys, "argv", [sys.argv[0], *remaining]):
        args = legacy.parse_arguments()
    if (
        args.steps != 1
        or not args.layer_trace
        or args.reference is None
        or args.capture_case is None
        or args.tp_reduction != "default"
        or args.device_offset != 0
        or args.trace_mlp_layer != 6
    ):
        parser.error(
            "Requires one captured M1, layer trace, HF and MoE layer6"
        )
    if options.check_inputs_only:
        from tilert.pd_vllm.ascend_cache import checkpoint_fingerprint

        rank = int(os.environ.get("RANK", "0"))
        metadata = checkpoint_fingerprint(args.checkpoint)
        prefixes, _, inputs = legacy.load_capture(
            args.capture_case, rank, metadata
        )
        reference = json.loads((args.reference / "manifest.json").read_text())
        legacy.validate_reference_manifest(reference, metadata, fp32_head=True)
        assert len(prefixes) == 78 and inputs["initial_position"] == 8192
        assert (
            reference["prefix_files_sha256"][f"rank-{rank}.pt"]
            == inputs["prefix_sha256"]
        )
        print(
            json.dumps(
                {
                    "inputs_verified": True,
                    "rank": rank,
                    "npu_executed": False,
                    "script_sha256": digest(__file__),
                }
            )
        )
        return 0

    import torch_npu

    from tilert.models.glm_5_2_ascend.cann_model import CannModel

    original_init = CannModel.__init__
    original_source = CannModel.source_metadata
    original_shutdown = CannModel.shutdown
    original_validate = legacy.validate_reference_manifest
    original_capture = legacy.capture_forward
    source_files = [
        Path(inspect.getfile(value)).resolve()
        for value in (
            original_init,
            original_validate,
            original_capture,
            install,
            install_routes,
            main,
        )
    ]
    sources = {str(path): digest(path) for path in source_files}
    engines, closed, restorers, paired_started = [], set(), {}, set()
    phase = {
        "recipe": "expanded" if options.recipe == "expanded" else "control"
    }
    matmul = torch_npu.npu.matmul
    initial_hf32 = matmul.allow_hf32
    matmul.allow_hf32 = False

    def initialize(engine, *engine_args, **engine_kwargs):
        engine_kwargs["fp32_head"] = True
        original_init(engine, *engine_args, **engine_kwargs)
        engines.append(engine)
        restorers[id(engine)] = []
        if options.recipe == "expanded":
            for layer in engine.model.model.layers:
                impl = layer.self_attn.mla_attn.mla_attn.impl
                restorers[id(engine)].append(install(impl))
        recipe = {
            "recipe": options.recipe,
            "layers": 78,
            "steps": 1,
            "fp32_head": engine.fp32_head,
            "graph": engine.graph is not None,
            "matmul_allow_hf32_before_experiment": initial_hf32,
            "matmul_allow_hf32_during_experiment": matmul.allow_hf32,
            "source_sha256": sources,
            "formal_precision_gate_passed": False,
            "performance_measured": False,
        }
        path = args.output / f"recipe-rank-{engine.rank}.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(recipe, indent=2) + "\n")

    def source_metadata(engine):
        return {**original_source(engine), **sources}

    def shutdown(engine):
        parent_path = args.output / f"rank-{engine.rank}.json"
        control_complete = parent_path.exists() and json.loads(
            parent_path.read_text()
        )["status"] in ("diagnostic", "captured")
        if (
            options.recipe == "paired"
            and id(engine) not in paired_started
            and control_complete
        ):
            from torch import distributed
            from vllm.distributed import get_world_group

            paired_started.add(id(engine))
            distributed.barrier(group=get_world_group().cpu_group)
            control = json.loads((args.output / "summary.json").read_text())
            if control["status"] in ("diagnostic", "captured"):
                phase["recipe"] = "expanded"
                capture_expanded(
                    engine,
                    args,
                    legacy,
                    install,
                    restorers[id(engine)],
                    sources,
                )
        for restore in reversed(restorers.pop(id(engine), [])):
            restore()
        try:
            original_shutdown(engine)
        finally:
            closed.add(id(engine))

    def validate(reference, metadata):
        return original_validate(reference, metadata, fp32_head=True)

    def capture(engine, *capture_args, **capture_kwargs):
        result = capture_routes(
            original_capture,
            install_routes,
            engine,
            *capture_args,
            **capture_kwargs,
        )
        result["attention_recipe"] = {
            "recipe": phase["recipe"],
            "matmul_allow_hf32": matmul.allow_hf32,
            "helper_sha256": sources[
                str(Path(inspect.getfile(install)).resolve())
            ],
        }
        return result

    os.environ["VLLM_USE_V2_MODEL_RUNNER"] = "0"
    try:
        with (
            patch.object(CannModel, "__init__", initialize),
            patch.object(CannModel, "source_metadata", source_metadata),
            patch.object(CannModel, "shutdown", shutdown),
            patch.object(legacy, "validate_reference_manifest", validate),
            patch.object(legacy, "capture_forward", capture),
        ):
            try:
                return legacy.execute(args)
            finally:
                for engine in engines:
                    if id(engine) not in closed:
                        shutdown(engine)
    finally:
        matmul.allow_hf32 = initial_hf32


if __name__ == "__main__":
    raise SystemExit(main())
