#!/bin/bash
set -e
exec /work/tools/strace/usr/bin/strace --seccomp-bpf -f -e trace=openat -o "/work/receipts/resident-pair-192-v1-rank-${RANK}-strace.log" python -B /work/receipts/resident-device-v1/run_resident.py --source /work/source-layer0-v1 --recipe paired "$@"
