"""Compare original and expanded attention through all 78 real M1 layers."""

import argparse
import hashlib
import importlib
import inspect
import sys
from functools import wraps
from pathlib import Path
from unittest.mock import patch


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def install_routes(layer, samples):
    from vllm_ascend.ascend_config import get_ascend_config
    from vllm_ascend.ascend_forward_context import _EXTRA_CTX

    routed = layer.mlp.experts.routed_experts
    original = routed._select_experts
    router = routed.router

    @wraps(original)
    def observed(
        hidden_states, router_logits, enable_force_load_balance, input_ids=None
    ):
        weights, ids = original(
            hidden_states, router_logits, enable_force_load_balance, input_ids
        )
        router_source = Path(inspect.getfile(type(router))).resolve()
        routed_source = Path(inspect.getfile(type(routed))).resolve()
        samples.append(
            {
                "ids": ids.detach().clone(),
                "weights": weights.detach().clone(),
                "router_logits": router_logits.detach().clone(),
                "metadata": {
                    "router_class": type(router).__module__
                    + "."
                    + type(router).__name__,
                    "top_k": router.top_k,
                    "eplb_state_known": hasattr(router, "eplb_state"),
                    "eplb_state_present": (
                        router.eplb_state is not None
                        if hasattr(router, "eplb_state")
                        else None
                    ),
                    "log2phy_present": routed.log2phy is not None,
                    "mix_placement": getattr(routed, "mix_placement", False),
                    "enable_force_eplb": get_ascend_config().enable_force_eplb,
                    "enable_force_load_balance": enable_force_load_balance,
                    "in_profile_run": getattr(
                        _EXTRA_CTX, "in_profile_run", None
                    ),
                    "source_sha256": {
                        str(router_source): digest(router_source),
                        str(routed_source): digest(routed_source),
                    },
                },
            }
        )
        return weights, ids

    replacement = patch.object(routed, "_select_experts", observed)
    replacement.start()
    return replacement.stop


def instrument(original, install, recipe, engine, factory, *args, **kwargs):
    import torch

    restorers, settings, route_samples = [], [], []

    def observed_factory(*factory_args, **factory_kwargs):
        layer = factory(*factory_args, **factory_kwargs)
        before = torch.npu.matmul.allow_hf32
        if recipe == "expanded":
            impl = layer.self_attn.mla_attn.mla_attn.impl
            restorers.append(install(impl))
        moe = hasattr(layer.mlp, "experts")
        if moe:
            restorers.append(install_routes(layer, route_samples))
        settings.append(
            {
                "recipe": recipe,
                "moe": moe,
                "matmul_allow_hf32_before": before,
                "matmul_allow_hf32_installed": torch.npu.matmul.allow_hf32,
            }
        )
        return layer

    try:
        result = original(engine, observed_factory, *args, **kwargs)
    finally:
        for restore in reversed(restorers):
            restore()
        restorers.clear()
    if len(settings) != 1:
        raise ValueError("Expected exactly one layer factory invocation")
    state, data, checks, coverage, sources, references = result
    settings[0]["matmul_allow_hf32_restored"] = torch.npu.matmul.allow_hf32
    data["attention_recipe"] = settings[0]
    checks.append(
        {
            "name": "actual_route_capture_count",
            "passed": len(route_samples) == int(settings[0]["moe"]),
        }
    )
    data["routes"] = data["route_weights"] = data["router_logits"] = None
    if route_samples:
        sample = route_samples[0]
        for field, key in (
            ("routes", "ids"),
            ("route_weights", "weights"),
            ("router_logits", "router_logits"),
        ):
            data[field] = sample[key].cpu().clone()
        data["routing_metadata"] = sample["metadata"]
        sources.update(sample["metadata"]["source_sha256"])
        checks.append(
            {
                "name": "actual_route_shapes",
                "passed": sample["ids"].shape
                == sample["weights"].shape
                == (1, sample["metadata"]["top_k"]),
            }
        )
    checks.append(
        {
            "name": "attention_recipe_restored",
            "passed": torch.npu.matmul.allow_hf32
            == settings[0]["matmul_allow_hf32_before"],
        }
    )
    for value in (original, install, instrument):
        source = Path(inspect.getfile(value)).resolve()
        sources[str(source)] = digest(source)
    return state, data, checks, coverage, sources, references


def main():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument(
        "--recipe", choices=("control", "expanded"), required=True
    )
    options, remaining = parser.parse_known_args()
    sys.path[:0] = [str(options.source), str(options.source / "tests/glm52")]
    legacy = importlib.import_module("run_cann_layer_major")
    from expanded_attention import install

    with patch.object(sys, "argv", [sys.argv[0], *remaining]):
        args = legacy.arguments()
    if (
        args.layers != 78
        or args.steps != 1
        or args.query_width != 1
        or args.attention_kernel != "sfa"
        or args.baseline is None
        or args.round_trace is not None
        or not args.fp32_head
    ):
        parser.error(
            "Requires 78 layers, M1, SFA, FP32 head and frozen baseline"
        )
    original = legacy.run_layer

    def observed(*args, **kwargs):
        return instrument(original, install, options.recipe, *args, **kwargs)

    with patch.object(legacy, "run_layer", observed):
        return legacy.execute(args)


if __name__ == "__main__":
    raise SystemExit(main())
