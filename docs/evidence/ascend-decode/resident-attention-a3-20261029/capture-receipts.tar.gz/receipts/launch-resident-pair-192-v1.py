from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess


ROOT = Path('/tmp/trt-canonical-20261029-192')
NAME = 'trt-bench-01a1819b-resident-pair-192-v1'
IMAGE = 'sha256:3892a691f3121830d1eedd843a62855c2d419975927da7564b22200ec654c734'
GOAL = '01a1819b-7bc8-7eb0-b016-746bd504e995'


def output(*args):
    return subprocess.check_output(args, text=True)


contract = json.loads((ROOT / 'receipts/resident-experiment-v1.json').read_text())
for relative, sha in contract['source_sha256'].items():
    assert hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() == sha
assert (ROOT / 'receipts/resident-inputs-192-v2-exit.txt').read_text().strip() == '0'
mem = dict(line.split(':', 1) for line in Path('/proc/meminfo').read_text().splitlines())
assert int(mem['MemAvailable'].split()[0]) >= 128 * 1024**2
(ROOT / 'receipts/resident-host-memory-before.txt').write_text(Path('/proc/meminfo').read_text())

receipt = json.loads((ROOT / 'receipts/checkpoint-new-consumer.json').read_text())
assert receipt['pass'] and len(receipt['files']) == 109
assert sum(item['bytes'] for item in receipt['files']) == 405008283962
assert (ROOT / 'receipts/checkpoint-new-consumer-exit.txt').read_text().strip() == '0'

reference = ROOT / 'hub/trt-a3-reference-20261028-2205/complete/manifest.json'
assert hashlib.sha256(reference.read_bytes()).hexdigest() == (
    '7667283d12e6c4e0b09e10c50ac64be10b4c8c57db5df0705bf4fbc8b25e990f'
)
assert subprocess.run(
    ['docker', 'inspect', NAME], capture_output=True
).returncode != 0
assert not (ROOT / 'receipts/resident-pair-192-v1-container-id.txt').exists()

ids = output('docker', 'ps', '-q').split()
containers = json.loads(output('docker', 'inspect', *ids)) if ids else []
now = datetime.now(timezone.utc)
for container in containers:
    started = container['State']['StartedAt']
    # Docker's nanosecond timestamp exceeds datetime's microsecond precision.
    started = re.sub(r'(\.\d{6})\d+Z$', r'\1+00:00', started)
    age = (now - datetime.fromisoformat(started)).total_seconds()
    assert age >= 180, container['Name']

before = output('npu-smi', 'info')
board = output('npu-smi', 'info', '-t', 'board', '-i', '0', '-c', '0')
(ROOT / 'receipts/before-resident-pair-192-v1.txt').write_text(
    now.isoformat() + '\n' + before + '\n' + board
)
assert '9392' in board or '9382' in board
assert before.count('No running processes found in NPU') == 8
memory = re.findall(r'(\d+)\s*/\s*65536', before)
assert len(memory) == 16 and all(int(value) <= 65536 * 0.08 for value in memory)

command = [
    'docker', 'run', '-d', '--runtime=ascend', '--network=host', '--ipc=host',
    '--name', NAME, '--label', f'trt.goal={GOAL}',
    '-e', 'ASCEND_VISIBLE_DEVICES=' + ','.join(map(str, range(16))),
    '-e', 'ASCEND_RT_VISIBLE_DEVICES=' + ','.join(map(str, range(16))),
    '-e', 'OMP_NUM_THREADS=1', '-e', 'MKL_NUM_THREADS=1',
]
mounts = [
    (ROOT, '/work', False),
    (ROOT / 'assets', '/assets', True),
    (ROOT / 'evidence', '/evidence', False),
    (ROOT / 'assets/model-view', '/models/glm52', True),
    (ROOT / 'weights/bucket-910c-6055/shanshan/tilert-ascend-20261018-84/models/GLM-5.2-w4a8c8', '/model-shards', True),
    (ROOT / 'assets/cann-9.2.0', '/opt/ascend/cann-9.2.0', True),
    (ROOT / 'assets/nnal', '/usr/local/Ascend/nnal', True),
    (ROOT / 'assets/kernel-overlay', '/opt/kernel-overlay', True),
    (Path('/usr/local/Ascend/driver'), '/usr/local/Ascend/driver', True),
    (Path('/usr/local/dcmi'), '/usr/local/dcmi', True),
    (Path('/usr/local/sbin/npu-smi'), '/usr/local/sbin/npu-smi', True),
]
for source, destination, readonly in mounts:
    assert source.exists(), str(source)
    command += ['-v', f'{source}:{destination}' + (':ro' if readonly else '')]
command += ['--entrypoint', '/bin/bash', IMAGE, '/work/receipts/resident-pair-192-v1.sh']
(ROOT / 'receipts/resident-pair-192-v1-docker-command.json').write_text(
    json.dumps(command, indent=2) + '\n'
)
container_id = output(*command).strip()
(ROOT / 'receipts/resident-pair-192-v1-container-id.txt').write_text(container_id + '\n')
print(json.dumps({'container_id': container_id, 'name': NAME, 'started_at': now.isoformat()}))
