"""Bind successful per-rank device/kernel opens to the terminal capture."""

import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile


ROOT = Path('/tmp/trt-canonical-20261029-192')
CID = '25da5d82510efc8b8676335dd1105dee72f93c28044894eb155dddc217c6918b'
container = json.loads(subprocess.check_output(['docker', 'inspect', CID], text=True))[0]
assert container['Config']['Labels']['trt.goal'] == '01a1819b-7bc8-7eb0-b016-746bd504e995'
assert container['State']['Status'] == 'exited' and container['State']['ExitCode'] == 0
mounts = sorted([(row['Destination'], row['Source']) for row in container['Mounts']], key=lambda row: len(row[0]), reverse=True)


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024**2), b''):
            value.update(block)
    return value.hexdigest()


def content(path):
    for target, source in mounts:
        if path.startswith(target + '/'):
            local = Path(source) / path[len(target) + 1:]
            if local.is_file():
                return local.read_bytes()
    packed = subprocess.check_output(['docker', 'cp', CID + ':' + path, '-'], stderr=subprocess.PIPE)
    with tarfile.open(fileobj=io.BytesIO(packed)) as archive:
        member = next(item for item in archive.getmembers() if item.isfile())
        return archive.extractfile(member).read()


records, all_kernels = [], set()
for rank in range(16):
    trace = ROOT / f'receipts/resident-pair-192-v1-rank-{rank}-strace.log'
    pending, opened = {}, set()
    with trace.open() as stream:
        for line in stream:
            pid = line.split(maxsplit=1)[0]
            match = re.search(r'openat\([^,]+, ("(?:[^"\\]|\\.)*")', line)
            if match:
                path = json.loads(match[1])
                if '<unfinished ...>' in line:
                    pending[pid] = path
                    continue
            elif '<... openat resumed>' in line:
                path = pending.pop(pid, None)
            else:
                continue
            if path and re.search(r'=\s*\d+(?:\s|$)', line):
                opened.add(path)
    kernels = sorted(path for path in opened if path.endswith('.o') and ('/kernel/' in path or '/kernel_meta/' in path or path.endswith('/dcache_lock_mix.o')))
    all_kernels.update(kernels)
    records.append({'rank': rank, 'trace_sha256': digest(trace), 'successful_device_opens': sorted(path for path in opened if path.startswith('/dev/davinci')), 'kernel_elf_opens': kernels})
files, unresolved = [], []
for path in sorted(all_kernels):
    try:
        raw = content(path)
        files.append({'path': path, 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw), 'elf_magic': raw[:4] == b'\x7fELF'})
    except (OSError, subprocess.CalledProcessError) as error:
        unresolved.append({'path': path, 'error': str(error)})
report = {'container_id': CID, 'container_state': container['State'], 'scope': 'Successful openat of davinci devices and kernel-directory .o files; not an execution trace or latency measurement', 'ranks': records, 'kernel_files': files, 'unresolved_kernel_paths': unresolved, 'script_sha256': digest(Path(__file__))}
path = ROOT / 'receipts/resident-pair-192-v1-kernels.json'
path.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'ranks': len(records), 'kernel_files': len(files), 'unresolved': len(unresolved), 'output': str(path)}))
