#!/bin/bash
set -e
exec /work/tools/strace/usr/bin/strace --seccomp-bpf -f -e trace=openat -o "/work/receipts/host-inputs-model-v1-rank-${RANK}-strace.log" python -B /work/source-host-inputs-v1/experiments/host-inputs/model_check.py "$@"
