from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess


ROOT = Path('/tmp/trt-canonical-20261029-192')
NAME = 'trt-bench-01a1819b-host-inputs-model-v1'
assert hashlib.sha256((ROOT/'source-host-inputs-v1/experiments/host-inputs/model_check.py').read_bytes()).hexdigest() == '209d8ba6d9f9b4cb262ed6bf246e18f4397ba78fa2dcf7a591d7a415341fe1cf'
(ROOT/'receipts/host-inputs-model-v1-contract.json').write_text(json.dumps({'scope': 'One resident TP16 world, separate/packet producer only; M1 first, M32, M32 reset; no performance timing', 'prediction': 'all6 forwards each rank match frozen actual old outputs bitwise; both producers match complete new KV/inputs; every phase retains prefix; all16 final-output states agree', 'source_sha256': {'model_check.py': '209d8ba6d9f9b4cb262ed6bf246e18f4397ba78fa2dcf7a591d7a415341fe1cf', 'cann_model.py': '7e5a9822426468b3e2b0a65da539da79536aac5d13a01c4d8047e8fd0bce47fd', 'host_inputs.py': 'f2f2286fb43ef4dbdf09b2bff6588be69b57f39de1855f5a3363a2b6d0ef6034'}, 'controls_reference_sha256': '1f3b3d62119d4e887dff91fbabefd397391d787a04414cbe7601e2a290af76fe', 'caches': 'shared resident numerical experiment; no performance claim', 'formal_precision_gate_passed': False, 'performance_measured': False},indent=2)+'\n')
assert subprocess.run(['docker', 'inspect', NAME], capture_output=True).returncode != 0
ids = subprocess.check_output(['docker', 'ps', '-q'], text=True).split()
containers = json.loads(subprocess.check_output(['docker', 'inspect', *ids], text=True)) if ids else []
now = datetime.now(timezone.utc)
for container in containers:
    if container['HostConfig']['Runtime'] == 'runc' and (container['Config']['Labels'] or {}).get('trt.goal') == '01a1819b-7bc8-7eb0-b016-746bd504e995':
        continue
    started = re.sub(r'(\.\d{6})\d+Z$', r'\1+00:00', container['State']['StartedAt'])
    assert (now - datetime.fromisoformat(started)).total_seconds() >= 180, container['Name']
raw = subprocess.check_output(['npu-smi', 'info'], text=True)
board = subprocess.check_output(['npu-smi', 'info', '-t', 'board', '-i', '0', '-c', '0'], text=True)
assert '9392' in board or '9382' in board
(ROOT / 'receipts/before-host-inputs-model-v1.txt').write_text(now.isoformat() + '\n' + raw + '\n' + board)
memory = {int(die): int(used) for die, used in re.findall(r'^\|\s*[01]\s+(\d+)\s+\|[^\n]*?(\d+)\s*/\s*65536\s*\|', raw, re.M)}
busy = {int(npu) * 2 + int(chip) for npu, chip, pid in re.findall(r'^\|\s*(\d+)\s+(\d+)\s+\|\s*(\d+)\s+\|', raw, re.M)}
free = sorted(die for die, used in memory.items() if used <= 65536 * 0.08 and die not in busy)
assert len(memory) == 16 and free == list(range(16))
die = '0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15'
(ROOT / 'receipts/before-host-inputs-model-v1.txt').write_text(now.isoformat() + '\n' + raw + '\n' + board)
command = json.loads((ROOT/'receipts/resident-pair-192-v1-docker-command.json').read_text())
for i,item in enumerate(command):
    if item.startswith('ASCEND_RT_VISIBLE_DEVICES='):
        command[i]='ASCEND_RT_VISIBLE_DEVICES=0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15'
command[command.index('--name') + 1] = NAME
for i, item in enumerate(command):
    if item.startswith('ASCEND_VISIBLE_DEVICES='):
        command[i] = f'ASCEND_VISIBLE_DEVICES={die}'
command[-1] = '/work/receipts/host-inputs-model-v1.sh'
(ROOT / 'receipts/host-inputs-model-v1-docker-command.json').write_text(json.dumps(command, indent=2) + '\n')
cid = subprocess.check_output(command, text=True).strip()
(ROOT / 'receipts/host-inputs-model-v1-container-id.txt').write_text(cid + '\n')
print(json.dumps({'container_id': cid, 'physical_die': die, 'logical_die': 0, 'free_dies_at_guard': free}))
