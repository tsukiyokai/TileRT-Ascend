import copy
import importlib.util
import io
import json
import os
import sys
import tempfile
import types
import unittest
from contextlib import ExitStack, redirect_stdout
from pathlib import Path
from unittest.mock import patch

import torch

ROOT=Path('/home/shanshan/repo/tile-ai/tilert-ascend')
sys.path[:0]=[str(ROOT),str(ROOT/'tests/glm52')]


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


fixture=load('host_fixture',ROOT/'tests/glm52/check_host_inputs.py')
entry=load('model_check',ROOT/'experiments/host-inputs/model_check.py')
import run_cann_model as legacy
import tilert.models.glm_5_2_ascend.cann_model as model_module
import tilert.models.glm_5_2_ascend.host_inputs as host_module

REAL_MODEL=model_module.CannModel
REAL_HOST=host_module.HostInputs
CHECKPOINT={'CPU-fixture':'identity'}
ENGINES=[]


def output_for(tokens):
    ids=torch.tensor(tokens,dtype=torch.int64)
    logits=torch.nn.functional.one_hot(ids%8,num_classes=8).float()
    return {'logits':logits,'last_hidden':ids.bfloat16().reshape(-1,1).repeat(1,2),'token_ids':logits.argmax(-1)}


class Engine(REAL_MODEL):
    corrupt_prefix=False
    def __init__(self,*args,**kwargs):
        self.__dict__.update(fixture.cpu_engine(False).__dict__)
        self.storage=torch.zeros(9344,2,dtype=torch.bfloat16)
        self.cache=[{'latent':self.storage}]
        self.calls=0;self.closed=0
        ENGINES.append(self)
    def reset(self):self.position=0
    def inject(self,prefixes):self.storage[:8192].copy_(prefixes[0]['latent']);self.position=8192
    def source_metadata(self):return {__file__:entry.digest(__file__)}
    def verify(self,tokens,*,full_logits):
        width,_=self._prepare_inputs(tokens)
        result=output_for(self.input_ids.tolist())
        self.storage[self.position:self.position+width].copy_(result['last_hidden'])
        self.position+=width;self.calls+=1
        if self.corrupt_prefix and self.calls%3!=2:self.storage[0,0]=1
        return types.SimpleNamespace(**result)
    def shutdown(self):self.closed+=1


def cpu_host(device,widths):return REAL_HOST('cpu',widths,pin_memory=False)


def load_capture(case,rank,checkpoint):
    return [{'latent':torch.zeros(8192,2,dtype=torch.bfloat16)}],[6500],{'initial_position':8192,'scope':'CPU fixture'}


class Main(unittest.TestCase):
    def call(self,root,*,corrupt=False,peer_failure=False,setup_failure=False):
        ENGINES.clear();Engine.corrupt_prefix=corrupt
        teacher=ROOT/'docs/evidence/ascend-decode/vllm-baseline-20261017/teacher-32.json'
        tokens=json.loads(teacher.read_text())['teacher_tokens']
        reference=root/'reference.pt'
        torch.save({'teacher_tokens':tokens,'checkpoint_sha256':CHECKPOINT,
                    'serial_first':output_for(tokens[:1]),'wide':output_for(tokens)},reference)
        group=types.SimpleNamespace(cpu_group=object(),barrier=lambda:None)
        vllm=types.ModuleType('vllm.distributed');vllm.get_world_group=lambda:group
        npu=types.ModuleType('torch_npu');npu.npu=types.SimpleNamespace(set_device=lambda rank:None,get_device_name=lambda rank:'Ascend910_9382')
        checkpoint=types.ModuleType('tilert.pd_vllm.ascend_cache');checkpoint.checkpoint_fingerprint=lambda path:CHECKPOINT
        def gather(rows,value,group):
            for rank in range(16):
                rows[rank]={**copy.deepcopy(value),'rank':rank}
                if peer_failure and rank==7:rows[rank]['status']='fail'
        digest=entry.digest
        def identity(path):
            return '1f3b3d62119d4e887dff91fbabefd397391d787a04414cbe7601e2a290af76fe' if Path(path)==reference else digest(path)
        argv=['model_check.py','--source',str(ROOT),'--checkpoint',str(root),'--capture-case',str(root),
              '--teacher',str(teacher),'--reference',str(reference),'--helpers',str(ROOT/'experiments/width-boundaries'),
              '--output',str(root/'output')]
        with ExitStack() as stack:
            stack.enter_context(fixture.vendor_metadata())
            stack.enter_context(patch.dict(os.environ,{'RANK':'0','LOCAL_RANK':'0','WORLD_SIZE':'16'}))
            stack.enter_context(patch.dict(sys.modules,{'torch_npu':npu,'vllm.distributed':vllm,checkpoint.__name__:checkpoint}))
            stack.enter_context(patch.object(torch,'npu',types.SimpleNamespace(matmul=types.SimpleNamespace(allow_hf32=True),synchronize=lambda:None),create=True))
            stack.enter_context(patch.object(torch.distributed,'all_gather_object',gather))
            stack.enter_context(patch.object(model_module,'CannModel',Engine))
            if setup_failure:
                stack.enter_context(patch.object(host_module,'HostInputs',side_effect=RuntimeError('setup failed')))
            else:stack.enter_context(patch.object(host_module,'HostInputs',cpu_host))
            stack.enter_context(patch.object(legacy,'load_capture',load_capture))
            stack.enter_context(patch.object(entry,'digest',identity))
            stack.enter_context(patch.object(sys,'argv',argv))
            stack.enter_context(redirect_stdout(io.StringIO()))
            return entry.main()

    def test_actual_main_runs_both_arms_all_phases_and_shuts_down(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);self.assertEqual(self.call(root),0)
            self.assertEqual((ENGINES[0].calls,ENGINES[0].closed),(6,1))
            report=json.loads((root/'output/rank-0.json').read_text())
            self.assertEqual(len(report['files_sha256']),6)
            self.assertEqual(len([x for x in report['checks'] if '.prefix.' in x['name']]),6)
            self.assertEqual(report['status'],'pass')
            self.assertFalse(report['formal_precision_gate_passed'])
            self.assertTrue(all(x['passed'] for x in report['checks']))

    def test_first_or_reset_prefix_corruption_is_rejected_despite_same_outputs(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);self.assertEqual(self.call(root,corrupt=True),1)
            self.assertEqual((ENGINES[0].calls,ENGINES[0].closed),(6,1))
            report=json.loads((root/'output/rank-0.json').read_text())
            failures=[x['name'] for x in report['checks'] if not x['passed']]
            self.assertTrue(all(any(name.startswith(mode+'-'+phase+'.prefix.') for name in failures)
                for mode in ('separate','packet') for phase in ('first','reset')))
            self.assertTrue(all(x['passed'] for x in report['checks'] if x['name'].endswith('.old_outputs')))

    def test_peer_failure_is_global_exit_one_and_setup_exception_also_cleans_up(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);self.assertEqual(self.call(root,peer_failure=True),1)
            self.assertEqual(ENGINES[0].closed,1)
            summary=json.loads((root/'output/summary.json').read_text())
            self.assertEqual(summary['status'],'fail')
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaisesRegex(RuntimeError,'setup failed'):self.call(Path(tmp),setup_failure=True)
            self.assertEqual((ENGINES[0].calls,ENGINES[0].closed),(0,1))


if __name__=='__main__':unittest.main(verbosity=2)
