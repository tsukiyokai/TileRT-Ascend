"""Actual CPU-reader entry and schema counterexamples, using saved metadata."""

import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import tarfile
import tempfile
import unittest
from contextlib import redirect_stdout
from unittest.mock import patch

import torch

ROOT = Path('/home/shanshan/repo/tile-ai/tilert-ascend')
SPEC = importlib.util.spec_from_file_location(
    'read_model', ROOT / 'experiments/host-inputs/read_model.py')
READER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(READER)
torch.set_num_threads(2)

with tarfile.open('/tmp/trt-host-inputs-model-metadata-192.tar') as archive:
    SUMMARY = json.load(archive.extractfile('evidence/host-inputs-model-v1/summary.json'))
    REPORTS = [json.load(archive.extractfile(
        f'evidence/host-inputs-model-v1/rank-{rank}.json')) for rank in range(16)]
    CONTRACT = json.load(archive.extractfile('receipts/host-inputs-model-v1-contract.json'))
    EXIT = json.load(archive.extractfile('receipts/host-inputs-model-v1-exit.json'))
TOKENS = json.loads((ROOT / 'docs/evidence/ascend-decode/vllm-baseline-20261017/teacher-32.json').read_text())['teacher_tokens']


def zeros(shape, dtype):
    value = torch.zeros((), dtype=dtype).expand(shape)
    return value.clone(memory_format=torch.contiguous_format) if value.numel() == 1 else value


def frame(mode='separate', phase='first'):
    width = 1 if phase == 'first' else 32
    return {
        'mode': mode, 'phase': phase, 'position': 8192,
        'committed_position': 8192 + width,
        'inputs': {
            'ids': torch.tensor(TOKENS[:width], dtype=torch.int32),
            'positions': torch.arange(8192, 8192 + width, dtype=torch.int64),
            'slots': torch.arange(8192, 8192 + width, dtype=torch.int32),
            'length': torch.tensor([8192 + width], dtype=torch.int32),
            'query': torch.tensor([0, width], dtype=torch.int32),
        },
        'outputs': {
            'logits': zeros((width, 154880), torch.float32),
            'last_hidden': zeros((width, 6144), torch.bfloat16),
            'token_ids': zeros((width,), torch.int64),
        },
        'new_cache': [{name: zeros((width,) if columns is None else (width, columns), dtype)
                       for name, (columns, dtype) in READER.cache_fields(layer).items()}
                      for layer in range(78)],
    }


class CpuReader(unittest.TestCase):
    def test_real_metadata_inventory_and_exit(self):
        READER.terminal(EXIT)
        for report in REPORTS:
            READER.report_checks(report)
            READER.source_identity(report)
        self.assertEqual(len(READER.expected_checks()), 1175)

    def test_full_actual_cli_entry_reads_16_ranks_and_96_small_storage_frames(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            reference = root / 'reference.pt'
            torch.save({'teacher_tokens': TOKENS,
                        'checkpoint_sha256': REPORTS[0]['checkpoint_sha256'],
                        'serial_first': frame()['outputs'],
                        'wide': frame(phase='wide')['outputs']}, reference)
            reference_sha = READER.digest(reference)
            states, files = {}, {}
            for mode in READER.MODES:
                for phase in READER.PHASES:
                    label = mode + '-' + phase
                    value = frame(mode, phase)
                    torch.save(value, root / (label + '.pt'))
                    files[label + '.pt'] = READER.digest(root / (label + '.pt'))
                    states[label] = READER.state_hash(value['outputs'])
            summary = copy.deepcopy(SUMMARY)
            for item, original in zip(summary['ranks'], REPORTS):
                rank = item['rank']
                target = root / f'rank-{rank}'
                target.mkdir()
                for filename in files:
                    os.link(root / filename, target / filename)
                report = copy.deepcopy(original)
                report.update(files_sha256=files, states=states, reference_sha256=reference_sha)
                path = root / f'rank-{rank}.json'
                path.write_text(json.dumps(report))
                item.update(report_sha256=READER.digest(path), states=states)
            (root / 'summary.json').write_text(json.dumps(summary))
            (root / 'exit.json').write_text(json.dumps(EXIT))
            contract = copy.deepcopy(CONTRACT)
            contract['controls_reference_sha256'] = reference_sha
            (root / 'contract.json').write_text(json.dumps(contract))
            args = ['read_model.py', '--capture', str(root), '--exit', str(root / 'exit.json'),
                    '--contract', str(root / 'contract.json'), '--reference', str(reference),
                    '--output', str(root / 'result.json')]
            with patch.object(READER, 'REFERENCE_SHA', reference_sha), patch.object(sys, 'argv', args), redirect_stdout(io.StringIO()):
                self.assertEqual(READER.main(), 0)
            result = json.loads((root / 'result.json').read_text())
            self.assertEqual((result['ranks'], result['frames'], result['producer_checks'], result['failed_count']),
                             (16, 96, 18800, 0))
            self.assertTrue(result['all_rank_final_output_states_agree'])
            self.assertFalse(result['formal_precision_gate_passed'])
            self.assertFalse(result['performance_measured'])
            self.assertNotIn('torch_npu', sys.modules)
            self.assertNotIn('vllm', sys.modules)
            # Re-sign every enclosing receipt while retaining all producer
            # pass assertions: only an actual raw-cache comparison can reject.
            changed = frame('packet', 'first')
            changed['new_cache'][0]['latent'] = torch.ones((1, 512), dtype=torch.bfloat16)
            path = root / 'rank-0/packet-first.pt'
            path.unlink()
            torch.save(changed, path)
            report_path = root / 'rank-0.json'
            report = json.loads(report_path.read_text())
            report['files_sha256']['packet-first.pt'] = READER.digest(path)
            report_path.write_text(json.dumps(report))
            summary['ranks'][0]['report_sha256'] = READER.digest(report_path)
            (root / 'summary.json').write_text(json.dumps(summary))
            with patch.object(READER, 'REFERENCE_SHA', reference_sha), patch.object(sys, 'argv', args), redirect_stdout(io.StringIO()):
                self.assertEqual(READER.main(), 1)
            result = json.loads((root / 'result.json').read_text())
            self.assertEqual(result['frames'], 96)
            self.assertEqual(result['failed'], ['rank0.first.packet_vs_separate.cache.0.latent'])
            self.assertFalse(result['formal_precision_gate_passed'])

    def test_empty_and_duplicate_checks_are_rejected(self):
        for mode in ('empty', 'duplicate'):
            report = copy.deepcopy(REPORTS[0])
            if mode == 'empty':
                report['checks'] = []
            else:
                report['checks'][-1]['name'] = report['checks'][0]['name']
            with self.subTest(mode=mode), self.assertRaises(ValueError):
                READER.report_checks(report)

    def test_failed_producer_check_cannot_be_promoted(self):
        report = copy.deepcopy(REPORTS[0])
        report['checks'][0]['passed'] = False
        with self.assertRaises(ValueError):
            READER.report_checks(report)

    def test_actual_input_dtype_is_enforced(self):
        value = frame()
        value['inputs']['ids'] = value['inputs']['ids'].long()
        with self.assertRaisesRegex(ValueError, 'Tensor layout'):
            READER.validate_frame(value, 'separate', 'first', TOKENS, 'fixture')

    def test_wrong_committed_position_is_rejected(self):
        value = frame()
        value['committed_position'] = 8192
        with self.assertRaisesRegex(ValueError, 'position'):
            READER.validate_frame(value, 'separate', 'first', TOKENS, 'fixture')

    def test_empty_cache_and_wrong_c8_dtype_are_rejected(self):
        for mode in ('empty', 'dtype'):
            value = frame()
            if mode == 'empty':
                value['new_cache'] = []
            else:
                value['new_cache'][6]['index_keys'] = zeros((1, 128), torch.bfloat16)
            with self.subTest(mode=mode), self.assertRaises(ValueError):
                READER.validate_frame(value, 'separate', 'first', TOKENS, 'fixture')

    def test_nonfinite_cache_is_rejected(self):
        value = frame()
        value['new_cache'][0]['rope'] = torch.full((1, 64), float('nan'), dtype=torch.bfloat16)
        with self.assertRaisesRegex(ValueError, 'Nonfinite'):
            READER.validate_frame(value, 'separate', 'first', TOKENS, 'fixture')

    def test_raw_cache_change_is_detected_with_all_producer_checks_true(self):
        left, right = frame(), frame()
        right['new_cache'][70]['index_keys'] = torch.ones((1, 128), dtype=torch.bfloat16)
        checks = READER.Checks()
        READER.same_frame(checks, 'fixture', left, right)
        self.assertEqual(checks.failed, ['fixture.cache.70.index_keys'])

    def test_exact_compares_bytes_including_signed_zero(self):
        self.assertFalse(READER.exact(torch.tensor([0.0]), torch.tensor([-0.0])))

    def test_exit_requires_string_wait0_and_terminal_exit0(self):
        for changed in ('wait_type', 'exit1', 'oom'):
            receipt = copy.deepcopy(EXIT)
            if changed == 'wait_type':
                receipt['docker_wait_exit'] = 0
            elif changed == 'exit1':
                receipt['state']['ExitCode'] = 1
            else:
                receipt['state']['OOMKilled'] = True
            with self.subTest(changed=changed), self.assertRaises(ValueError):
                READER.terminal(receipt)


if __name__ == '__main__':
    unittest.main(verbosity=2)
