from Cython.Build import cythonize
from setuptools import Extension, setup

setup(
    name="tilert-lookup-native",
    ext_modules=cythonize(
        [Extension('tilert.models.glm_5_2_ascend.lookup_draft', ['tilert/models/glm_5_2_ascend/lookup_draft.py'])],
        compiler_directives={'language_level': 3, 'infer_types': False, 'binding': True, 'boundscheck': True, 'wraparound': True, 'nonecheck': True, 'overflowcheck': True},
        include_path=["."],
        annotate=True,
    ),
)
