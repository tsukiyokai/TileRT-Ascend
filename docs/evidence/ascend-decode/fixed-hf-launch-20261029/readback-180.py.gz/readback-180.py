from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path


ROOT = Path('/tmp/trt-gmm1-20261029-0030')
FOLDER = ROOT / 'evidence/full-fixed-v3'
summary_path = FOLDER / 'summary.json'
summary_bytes = summary_path.read_bytes()
summary = json.loads(summary_bytes)
ranks = []
families = ('hf.serial', 'hf.wide', 'hf.reset', 'serial_vs_wide',
            'serial_vs_reset', 'reset_exact')

for rank in range(16):
    path = FOLDER / f'rank-{rank}.json'
    raw = path.read_bytes()
    report = json.loads(raw)
    sha256 = hashlib.sha256(raw).hexdigest()
    frozen = next(item for item in summary['ranks'] if item['rank'] == rank)
    assert sha256 == frozen['report_sha256']
    checks = report['checks']
    failed = [item for item in checks if not item['passed']]
    groups = {}
    for family in families:
        selected = [item for item in checks
                    if item['name'].startswith(family + '.')]
        bad = [item for item in selected if not item['passed']]
        groups[family] = {
            'checks': len(selected), 'failed': len(bad),
            'first_failed': bad[:4],
        }
    ranks.append({
        'rank': rank, 'report_sha256': sha256,
        'status': report['status'], 'capture_complete': report['capture_complete'],
        'checks_total': len(checks), 'checks_failed': len(failed),
        'failed_families': dict(Counter(item['name'].split('.')[0]
                                       for item in failed)),
        'groups': groups,
        'source_sha256': report['source_sha256'],
        'loaded_libraries_sha256': report['loaded_libraries_sha256'],
    })

result = {
    'scope': 'One frozen 8K/32-row eager TP16 numerical capture, not TPOT',
    'observed_at': datetime.now(timezone.utc).isoformat(),
    'source_commit': '3fcfd8b4904bc609888150d83d4b9137f4bcae63',
    'summary_sha256': hashlib.sha256(summary_bytes).hexdigest(),
    'summary': summary, 'ranks': ranks,
    'first_hf': json.loads((ROOT / 'receipts/full-fixed-v3-first-hf.json').read_text()),
    'tensor_files': len(list(FOLDER.rglob('*.pt'))),
}
output = ROOT / 'receipts/full-fixed-v3-readback.json'
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({
    'tensor_files': result['tensor_files'],
    'status': summary['status'],
    'all_rank_state_agreement': summary['all_rank_state_agreement'],
    'rank0_groups': {key: {'checks': value['checks'], 'failed': value['failed'],
                          'first_failed': [item['name'] for item in value['first_failed']]}
                     for key, value in ranks[0]['groups'].items()},
}))
