import importlib.util
import json
from pathlib import Path
import torch

root = Path('/work')
path = root / 'source-v12/experiments/cann-precision/run.py'
spec = importlib.util.spec_from_file_location('first_row_entry', path)
entry = importlib.util.module_from_spec(spec)
spec.loader.exec_module(entry)
actual_path = root / 'evidence/full-fixed-v3/rank-0/serial-00.pt'
reference_dir = root / 'hub/trt-a3-reference-20261028-2205/complete'
reference_path = reference_dir / 'step-08192.pt'
reference_manifest = json.loads((reference_dir / 'manifest.json').read_text())
assert entry.digest(reference_path) == reference_manifest['trace_sha256'][reference_path.name]
actual = torch.load(actual_path, map_location='cpu', weights_only=True)
expected = torch.load(reference_path, map_location='cpu', weights_only=True)
selected = entry.single_row(actual, 0, choices=True)
checks = []
entry.strict_row('hf.fixed.first', selected, expected, checks)
receipt = {
    'scope': 'Rank0 first actual M1 from fixed TP16 vs independent CPU HF; no whole-case or TPOT acceptance',
    'source_commit': '3fcfd8b4904bc609888150d83d4b9137f4bcae63',
    'cann_sha256': entry.digest(actual_path),
    'hf_sha256': entry.digest(reference_path),
    'helper_sha256': entry.digest(Path(__file__)),
    'checks_total': len(checks),
    'checks_failed': sum(not value['passed'] for value in checks),
    'prediction': int(selected['token_ids'][0]),
    'hf_prediction': int(expected['logits'].argmax(-1)[0]),
    'checks': checks,
    'precision_verified': False,
    'formal_precision_gate_passed': False,
}
(root / 'receipts/full-fixed-v3-first-hf.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: value for key, value in receipt.items() if key != 'checks'}))
for value in checks:
    if value['name'].endswith('.logits') or value['name'].endswith('.hidden_states.1'):
        print(json.dumps(value))
