import importlib.util
import io
import json
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import patch

ROOT = Path('/home/shanshan/repo/tile-ai/tilert-ascend')
sys.path.insert(0, str(ROOT / 'experiments/cann-precision'))
import history_context as reader
import torch

spec = importlib.util.spec_from_file_location('fixture_source', '/tmp/trt-width-firstdiff-check-20261029.py')
fixtures = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixtures)
torch.set_num_threads(2)


class Context(unittest.TestCase):
    def test_selected_layout_does_not_read_other_layers(self):
        frame = fixtures.frame(1, [24187], 8205)
        for field in ('hidden_states', 'indices', 'routes', 'cache_rows'):
            kept = frame[field][68]
            frame[field] = [None] * 69
            frame[field][68] = kept
        reader.selected_frame(frame, [24187], 8205)
        with self.assertRaisesRegex(ValueError, 'identity'):
            reader.selected_frame(frame, [24187], 8206)
        frame['cache_rows'][68]['latent'] = torch.zeros(1, 512)
        with self.assertRaisesRegex(ValueError, 'layout'):
            reader.selected_frame(frame, [24187], 8205)

    def test_history_membership_is_not_caused_by_hidden_or_route_changes(self):
        serial = fixtures.frame(1, [24187], 8205)
        wide = fixtures.frame(32, list(range(32)), 8192)
        wide['hidden_states'][68] = wide['hidden_states'][68].clone()
        wide['hidden_states'][68][13, 0] = 1
        wide['routes'][68] = wide['routes'][68].flip(-1)
        row = reader.compare_row(serial, wide, 13)
        self.assertFalse(row['fields']['h68']['bit_equal'])
        self.assertTrue(row['fields']['routes']['sets_equal'])
        self.assertFalse(row['fields']['routes']['order_equal'])
        selection = reader.history_selection([row], serial['indices'][68], wide['indices'][68][13])
        self.assertTrue(selection['all_14_new_kv_rows_bit_equal'])

    def test_full_cli_hashes_all_serials_and_finds_selected_history(self):
        teacher = ROOT / 'docs/evidence/ascend-decode/vllm-baseline-20261017/teacher-32.json'
        tokens = json.loads(teacher.read_text())['teacher_tokens']
        with tempfile.TemporaryDirectory() as tmp:
            directory = Path(tmp)
            (directory / 'rank-0').mkdir()
            wide = fixtures.frame(32, tokens, 8192)
            for field in ('latent', 'rope'):
                wide['cache_rows'][68][field] = wide['cache_rows'][68][field].clone()
            wide['cache_rows'][68]['latent'][0, 0] = 1
            wide['cache_rows'][68]['rope'][5, 0] = 1
            wide['indices'][68] = wide['indices'][68].clone()
            wide['indices'][68][13, -1] = 8192
            hashes = {}
            path = directory / 'rank-0/wide.pt'
            torch.save(wide, path)
            hashes['wide.pt'] = reader.frozen.digest(path)
            for row in range(14):
                serial = fixtures.frame(1, [tokens[row]], 8192 + row)
                serial['model_inputs'] = {name: torch.tensor(values) for name, values in {
                    'input_ids': [tokens[row]], 'positions': [8192+row], 'slots': [8192+row],
                    'query_cpu': [0, 1], 'seq_lens': [8193+row]}.items()}
                if row == 13:
                    serial['indices'][68] = wide['indices'][68][13:14].clone()
                name = f'serial-{row:02d}.pt'
                path = directory / 'rank-0' / name
                torch.save(serial, path)
                hashes[name] = reader.frozen.digest(path)
            report = {'rank': 0, 'world_size': 16, 'capture_complete': True,
                      'mode': 'strict_hf', 'status': 'fail',
                      'source_commit': '3fcfd8b4904bc609888150d83d4b9137f4bcae63',
                      'teacher': {'sha256': reader.frozen.TEACHER_SHA256, 'teacher_tokens': tokens},
                      'inputs': {'initial_position': 8192, 'first_token_id': tokens[0]},
                      'source_sha256': reader.frozen.SOURCE_BINDINGS,
                      'trace_sha256': hashes.copy(), 'checkpoint_sha256': {'fixture': 'CPU-only'},
                      'checks': [{'name': 'serial.prefix.0.latent', 'passed': True},
                                 {'name': 'wide.prefix.0.latent', 'passed': True}]}
            (directory / 'rank-0.json').write_text(json.dumps(report))
            hashes['rank-0.json'] = reader.frozen.digest(directory / 'rank-0.json')
            (directory / 'summary.json').write_text(json.dumps({
                'ranks': [{'rank': 0, 'report_sha256': hashes['rank-0.json']}],
                'all_rank_state_agreement': True}))
            hashes['summary.json'] = reader.frozen.digest(directory / 'summary.json')
            output = directory / 'history.json'
            argv = ['history_context.py', '--capture-dir', str(directory), '--teacher', str(teacher),
                    '--output', str(output)]
            with patch.object(reader.frozen, 'FROZEN_SHA256', hashes), patch.object(sys, 'argv', argv), redirect_stdout(io.StringIO()):
                reader.main()
            result = json.loads(output.read_text())
            self.assertEqual(len(result['rows']), 14)
            self.assertEqual(result['changed_history_positions'], [8192, 8197])
            self.assertEqual(result['row13_selection']['wide']['selected_changed_history_positions'], [8192])
            self.assertEqual(result['row13_selection']['serial']['selected_changed_history_positions'], [8192])
            self.assertEqual(set(result['identities']) - {'summary.json', 'rank-0.json', 'teacher', 'wide.pt'},
                             {f'serial-{row:02d}.pt' for row in range(14)})
            self.assertFalse(result['formal_precision_gate_passed'])
            self.assertFalse(any(name.startswith(('vllm', 'torch_npu')) for name in sys.modules))
            # An older history row is independently checked, not only serial13.
            with (directory / 'rank-0/serial-07.pt').open('ab') as stream:
                stream.write(b'changed')
            with patch.object(reader.frozen, 'FROZEN_SHA256', hashes), patch.object(sys, 'argv', argv), self.assertRaisesRegex(ValueError, 'SHA256 mismatch'):
                reader.main()


if __name__ == '__main__':
    unittest.main(verbosity=2)
