set -e
export TORCH_DEVICE_BACKEND_AUTOLOAD=0
source /opt/ascend/cann-9.2.0/set_env.sh
source /usr/local/Ascend/nnal/atb/set_env.sh
set -u
export PYTHONPATH=/work/source-layer0-v1${PYTHONPATH:+:$PYTHONPATH}
export LD_LIBRARY_PATH=/opt/openEuler/gcc-toolset-12/root/usr/lib64${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}
export PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=8 MKL_NUM_THREADS=8
export ASCEND_CUSTOM_OPP_PATH=/opt/kernel-overlay/vendors/custom_transformer:/work/runtime-sfa-token/vllm_ascend/_cann_ops_custom/vendors/custom_transformer${ASCEND_CUSTOM_OPP_PATH:+:$ASCEND_CUSTOM_OPP_PATH}
export ASCEND_GLOBAL_LOG_LEVEL=3 ASCEND_SLOG_PRINT_TO_STDOUT=0
set +e
timeout 600 python -B /work/receipts/prefix-bench-v1/bench_device.py --fixture /prefix-values/layer0-expanded-first-difference.pt --native-capture /work/inputs/native-sfa-rank2-v1/layer-00.pt --bank /prefix-values/output/rank-2.pt --bank-receipt /prefix-values/output/rank-2.json --original /work/receipts/resident-device-v1/expanded_attention.py --cached /work/receipts/prefix-values-device-v1/attention.py --device-source /work/runtime-sfa-token/vllm_ascend/device/device_op.py --sfa-source /assets/vllm-ascend-unified/vllm_ascend/attention/sfa_v1.py --custom-library /assets/vllm-ascend-unified/vllm_ascend/vllm_ascend_C.cpython-311-aarch64-linux-gnu.so --source-commit 864d34aeaa9dd8aa645e526c780daa1777c2fd50 --output /work/evidence/prefix-bench-v1/report.json --warmup 12 --samples 60 > /work/receipts/prefix-bench-v1-driver.log 2>&1
status=$?
echo "$status" > /work/receipts/prefix-bench-v1-exit.txt
exit "$status"
