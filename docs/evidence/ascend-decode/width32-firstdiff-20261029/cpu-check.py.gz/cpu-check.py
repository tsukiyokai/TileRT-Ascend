import importlib.util
import io
import json
import math
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import patch

import torch

ROOT = Path('/home/shanshan/repo/tile-ai/tilert-ascend')
spec = importlib.util.spec_from_file_location('firstdiff', ROOT / 'experiments/cann-precision/first_difference.py')
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)
spec = importlib.util.spec_from_file_location('original', ROOT / 'tests/glm52/run_native_decode.py')
original = importlib.util.module_from_spec(spec)
spec.loader.exec_module(original)
torch.set_num_threads(2)


def frame(width, tokens, position):
    def values(size, dtype):
        return torch.zeros(1, size, dtype=dtype).expand(width, size)
    hidden = values(6144, torch.bfloat16)
    logits = values(154880, torch.float32)
    index = torch.arange(2048, dtype=torch.int32).reshape(1, -1).expand(width, -1)
    routes = torch.arange(8, dtype=torch.int32).reshape(1, -1).expand(width, -1)
    caches = []
    for layer in range(78):
        full = layer < 3 or (layer - 2) % 4 == 0
        quantized = full and 6 <= layer <= 66
        caches.append({'latent': values(512, torch.bfloat16), 'rope': values(64, torch.bfloat16),
                       'index': values(128, torch.int8 if quantized else torch.bfloat16) if full else None,
                       'index_scale': torch.ones(width, 1, dtype=torch.float16) if quantized else None})
    return {'token': tokens, 'position': position, 'committed_position': position + width,
            'logits': logits, 'last_hidden': hidden, 'token_ids': torch.zeros(width, dtype=torch.long),
            'hidden_states': [hidden] * 79, 'layer_logits': [logits] * 78,
            'indices': [index] * 78, 'routes': [None] * 3 + [routes] * 75, 'cache_rows': caches}


class Readback(unittest.TestCase):
    def test_metric_contract_matches_original(self):
        generator = torch.Generator().manual_seed(7)
        cases = [torch.randn(1, 6144, generator=generator).bfloat16(),
                 torch.zeros(1, 128), torch.arange(128, dtype=torch.int8).reshape(1, -1),
                 torch.tensor([1.0], dtype=torch.float16)]
        for expected in cases:
            for factor in (1.0, 1.001, 1.2):
                actual = (expected.float() * factor).to(expected.dtype)
                for exact in (False, True):
                    old = []
                    original.compare_tensor('x', actual, expected, old, exact=exact)
                    new = reader.compare(actual, expected, exact=exact)
                    self.assertEqual(new['original_passed'], old[0]['passed'])
                    for name in ('nrmse', 'cosine', 'max_abs'):
                        self.assertEqual(new[name], old[0][name])
        for actual, expected in [(torch.tensor([[0., -0.]]), torch.tensor([[0., 0.]])),
                                 (torch.tensor([[float('nan')]]), torch.tensor([[1.]]))]:
            old = []
            original.compare_tensor('x', actual, expected, old)
            new = reader.compare(actual, expected)
            self.assertEqual(new['original_passed'], old[0]['passed'])
            self.assertFalse(new['bit_equal'])
        expected = torch.zeros(1, 154880)
        actual = expected.clone()
        actual[0, 12] = 0.11
        old = []
        original.compare_tensor('x', actual, expected, old, logits=True)
        self.assertEqual(reader.compare(actual, expected, logits=True)['original_passed'], old[0]['passed'])

    def test_choices_distinguish_order_set_and_invalid_causality(self):
        expected = torch.arange(2048, dtype=torch.int32).reshape(1, -1)
        changed = expected.flip(-1)
        metrics = reader.choices(changed, expected, 'indices', 8205)
        self.assertTrue(metrics['original_passed'])
        self.assertFalse(metrics['bit_equal'])
        self.assertTrue(metrics['sets_equal'])
        self.assertFalse(metrics['order_equal'])
        changed = expected.clone()
        changed[0, -1] = 8190
        self.assertFalse(reader.choices(changed, expected, 'indices', 8205)['original_passed'])
        changed[0, -1] = 9000
        self.assertFalse(reader.choices(changed, changed, 'indices', 8205)['selection_valid'])

    def test_full_cpu_cli_mmap_identity_and_boundaries(self):
        teacher = ROOT / 'docs/evidence/ascend-decode/vllm-baseline-20261017/teacher-32.json'
        tokens = json.loads(teacher.read_text())['teacher_tokens']
        with tempfile.TemporaryDirectory() as tmp:
            directory = Path(tmp)
            (directory / 'rank-0').mkdir()
            serial = frame(1, [tokens[13]], 8205)
            serial['model_inputs'] = {name: torch.tensor(values) for name, values in {
                'input_ids': [tokens[13]], 'positions': [8205], 'slots': [8205],
                'query_cpu': [0, 1], 'seq_lens': [8206]}.items()}
            wide = frame(32, tokens, 8192)
            # Tiny exact mismatch before a later true set mismatch.
            serial['hidden_states'][4] = torch.ones(1, 6144, dtype=torch.bfloat16)
            wide['hidden_states'][4] = torch.ones(32, 6144, dtype=torch.bfloat16)
            wide['hidden_states'][4][13, 0] = 1.0078125
            wide['indices'][70] = wide['indices'][70].clone()
            wide['indices'][70][13, -1] = 8190
            raw_hashes = {}
            for name, value in [('serial-13.pt', serial), ('wide.pt', wide)]:
                path = directory / 'rank-0' / name
                torch.save(value, path)
                raw_hashes[name] = reader.digest(path)
            report = {'rank': 0, 'world_size': 16, 'capture_complete': True,
                      'mode': 'strict_hf', 'status': 'fail',
                      'source_commit': '3fcfd8b4904bc609888150d83d4b9137f4bcae63',
                      'teacher': {'sha256': reader.TEACHER_SHA256, 'teacher_tokens': tokens},
                      'inputs': {'initial_position': 8192, 'first_token_id': tokens[0]},
                      'source_sha256': reader.SOURCE_BINDINGS,
                      'trace_sha256': raw_hashes, 'checkpoint_sha256': {'fixture': 'CPU-only'}}
            report_path = directory / 'rank-0.json'
            report_path.write_text(json.dumps(report))
            report_sha = reader.digest(report_path)
            (directory / 'summary.json').write_text(json.dumps({
                'ranks': [{'rank': 0, 'report_sha256': report_sha}], 'all_rank_state_agreement': True}))
            hashes = {**raw_hashes, 'rank-0.json': report_sha,
                      'summary.json': reader.digest(directory / 'summary.json')}
            output = directory / 'result.json'
            argv = ['first_difference.py', '--capture-dir', str(directory),
                    '--teacher', str(teacher), '--output', str(output)]
            with patch.object(reader, 'FROZEN_SHA256', hashes), patch.object(sys, 'argv', argv), redirect_stdout(io.StringIO()):
                reader.main()
            result = json.loads(output.read_text())
            self.assertEqual(result['first_bit_difference']['layer'], 3)
            self.assertEqual(result['first_original_threshold_failure']['layer'], 70)
            self.assertEqual(result['first_original_threshold_failure']['fields'], ['indices'])
            self.assertEqual(result['token'], 24187)
            self.assertFalse(result['formal_precision_gate_passed'])
            self.assertFalse(any(name.startswith(('vllm', 'torch_npu')) for name in sys.modules))
            # Real byte mutation must invalidate the input before deserialization.
            with (directory / 'rank-0/wide.pt').open('ab') as stream:
                stream.write(b'changed')
            with patch.object(reader, 'FROZEN_SHA256', hashes), self.assertRaisesRegex(ValueError, 'SHA256 mismatch'):
                reader.receipts(directory, teacher)

    def test_wrong_position_and_missing_field_rejected(self):
        value = frame(1, [24187], 8205)
        with self.assertRaisesRegex(ValueError, 'identity'):
            reader.validate_frame(value, [24187], 8206)
        value['hidden_states'] = value['hidden_states'][:78]
        with self.assertRaisesRegex(ValueError, 'Incomplete'):
            reader.validate_frame(value, [24187], 8205)


if __name__ == '__main__':
    unittest.main(verbosity=2)
