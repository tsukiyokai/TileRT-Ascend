import copy
import importlib.util
import io
import json
import sys
import tarfile
import tempfile
import types
import unittest
from collections import deque
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import patch

import torch

ROOT=Path('/home/shanshan/repo/tile-ai/tilert-ascend')
sys.path.insert(0,str(ROOT/'experiments/width-boundaries'))
spec=importlib.util.spec_from_file_location('bench',ROOT/'experiments/width-boundaries/bench_order.py')
bench=importlib.util.module_from_spec(spec);spec.loader.exec_module(bench)
torch.set_num_threads(2)
with tarfile.open('/tmp/trt-sfa-order-v1-receipts.tar') as archive:
    input_bytes=archive.extractfile('evidence/sfa-order-v1/inputs.pt').read()
    report=json.loads(archive.extractfile('evidence/sfa-order-v1/report.json').read())
import hashlib
assert hashlib.sha256(input_bytes).hexdigest()==report['inputs_file_sha256']
REAL=torch.load(io.BytesIO(input_bytes),map_location='cpu',weights_only=True)


def wide_frame(sorted_arm=False):
    tokens=json.loads((ROOT/'docs/evidence/ascend-decode/vllm-baseline-20261017/teacher-32.json').read_text())['teacher_tokens']
    inputs={name:value.clone() for name,value in REAL['inputs'].items()}
    inputs['ql_nope']=torch.arange(32,dtype=torch.float32).reshape(32,1,1).expand(32,4,512).bfloat16().clone()
    inputs['q_pe']=torch.arange(32,dtype=torch.float32).reshape(32,1,1).expand(32,4,64).bfloat16().clone()
    source=torch.arange(2048,dtype=torch.int32).flip(0).reshape(1,1,-1).repeat(32,1,1)
    inputs['topk_indices']=source.sort(-1).values if sorted_arm else source
    tensors={bench.numerical.PREFIX+name:value for name,value in inputs.items()}
    if sorted_arm:tensors['intervention.original_indices']=source
    for name,number in [('actual_seq_lengths_query',32),('actual_seq_lengths_key',8224)]:
        tensors[bench.numerical.PREFIX+name]=torch.tensor([number],dtype=torch.int32)
    output=torch.arange(32,dtype=torch.float32).reshape(32,1,1).expand(32,4,512).bfloat16().clone()
    if sorted_arm:output+=1
    tensors[bench.numerical.PREFIX+'out']=output
    return {'tokens':tokens,'position':8192,'committed_position':8224,
        'model_inputs':{name:torch.tensor(value) for name,value in {'input_ids':tokens,'positions':list(range(8192,8224)),
             'slots':list(range(8192,8224)),'query_cpu':[0,32],'seq_lens':[8224]}.items()},
        'observed':{'tensors':tensors,'coverage':{'fixture':True},'metadata':{
          'source_sha256':{'/frozen'+key:sha for key,sha in bench.numerical.OBSERVED_SOURCES.items()},
          'tensor_layouts':{key:{'device':'npu:12'} for key in tensors},'scalar_values':{},'sfa_calls':[{'scale':.0625}]}}}


class Checks(unittest.TestCase):
    def test_actual_metadata_and_all_three_execute_paths_keep_inputs(self):
        self.assertEqual(bench.digest(Path(bench.numerical.__file__)),bench.HELPER_SHA)
        self.assertEqual(report['metadata_lengths']['actual_seq_lengths_query']['dtype'],'torch.int32')
        self.assertEqual(report['m32_lengths_not_replayed']['actual_seq_lengths_key']['values'],[8224])
        for width in (1,32):
            inputs=copy.deepcopy(REAL['inputs']) if width==1 else {name:wide_frame()['observed']['tensors'][bench.numerical.PREFIX+name] for name in REAL['inputs']}
            ordered=inputs['topk_indices'].sort(-1).values
            lengths={name:bench.numerical.runtime_length(value,'cpu') for name,value in REAL['lengths'].items()}
            if width==32:lengths={'actual_seq_lengths_query':torch.tensor([32],dtype=torch.int32),'actual_seq_lengths_key':torch.tensor([8224],dtype=torch.int32)}
            before=bench.numerical.raw_sha(inputs['topk_indices'])
            for arm in bench.ARMS:
                calls=[]
                def operation(cls,impl,ql,pe,kv,indices,metadata,query_lengths,key_lengths,*,block_table):
                    calls.append(indices)
                    self.assertEqual(ql.shape,(width,4,512))
                    self.assertIs(query_lengths,lengths['actual_seq_lengths_query'])
                    self.assertIs(block_table,inputs['block_table'])
                    return torch.zeros(width,4,512,dtype=torch.bfloat16)
                output=bench.make_execute(arm,operation,inputs,ordered,lengths,.0625)()
                self.assertEqual(output.shape,(width,4,512))
                expected=inputs['topk_indices'] if arm=='native' else ordered
                self.assertTrue(torch.equal(calls[0],expected))
                self.assertEqual(bench.numerical.raw_sha(inputs['topk_indices']),before)
                if arm=='sort_each':self.assertNotEqual(calls[0].data_ptr(),inputs['topk_indices'].data_ptr())

    def test_pressure_and_sha_checks_are_outside_actual_dual_clock_interval(self):
        events=[]
        class Pressure:
            def add_(self,value):events.append('pressure')
        class Event:
            def __init__(self,name):self.name=name
            def record(self):events.append(self.name)
            def elapsed_time(self,other):return .002
        def execute():events.append('SFA');return torch.zeros(1)
        with patch.object(torch,'npu',types.SimpleNamespace(synchronize=lambda:events.append('sync')),create=True),patch.object(bench,'perf_counter_ns',side_effect=[100,3100]):
            _,times=bench.measure(execute,Pressure(),Event('begin'),Event('end'))
        self.assertEqual(events,['pressure','sync','begin','SFA','end','sync'])
        self.assertEqual(times,{'wall_us':3.,'event_us':2.})

    def test_full_width32_admission_keeps_every_row_and_rejects_row0_mismatch(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'rank-12').mkdir()
            original,ordered=wide_frame(),wide_frame(True)
            torch.save(original,root/'rank-12/original-wide.pt')
            def save_ordered():
                path=root/'rank-12/sorted-wide.pt';torch.save(ordered,path);sha=bench.digest(path)
                (root/'rank-12.json').write_text(json.dumps({'trace_sha256':{'sorted-wide.pt':sha}}))
                return sha
            sha=save_ordered()
            with patch.object(bench.numerical,'admit',return_value=REAL),patch.object(bench,'SORTED_WIDE_SHA',sha):
                result=bench.fixtures(root)
            self.assertEqual(result[32]['inputs']['ql_nope'].shape,(32,4,512))
            self.assertFalse(torch.equal(result[32]['inputs']['ql_nope'][0],result[32]['inputs']['ql_nope'][13]))
            self.assertEqual(result[32]['expected']['preordered'].shape,(32,4,512))
            ordered['observed']['tensors'][bench.numerical.PREFIX+'ql_nope'][0,0,0]+=1
            sha=save_ordered()
            with patch.object(bench.numerical,'admit',return_value=REAL),patch.object(bench,'SORTED_WIDE_SHA',sha),self.assertRaisesRegex(ValueError,'Full width32 query differs'):
                bench.fixtures(root)

    def test_stats_keep_p90_p99_and_cost_inclusive_prediction_separate(self):
        rows=[{arm:{'wall_us':value,'event_us':value} for arm,value in [('native',100.),('preordered',90.),('sort_each',110.)]} for _ in range(60)]
        value=bench.summarize(rows)
        self.assertTrue(value['preordered_prediction_met'])
        self.assertFalse(value['sort_each_including_cost_prediction_met'])
        self.assertEqual(set(value['timings']['native']['wall_us']),{'p50','p90','p95','p99','min','max','std'})
        self.assertEqual(bench.stats(list(range(60)))['p99'],58)
        self.assertEqual(len(bench.ORDERS),6)
        self.assertTrue(all(sum(order[slot]==arm for order in bench.ORDERS)==2 for slot in range(3) for arm in bench.ARMS))

    def test_actual_controller_runs_six_private_workers_and_all_72_groups(self):
        prepared={1:{'width':1,'expected':{'native':REAL['expected']['original'],'preordered':REAL['expected']['sorted'],'sort_each':REAL['expected']['sorted']},'identities':{}},
                  32:{'width':32,'expected':{arm:torch.zeros(32,4,512,dtype=torch.bfloat16) for arm in bench.ARMS},'identities':{},'sorted_wide_identity':{}}}
        created=[]
        class Process:
            def __init__(self,command,**kwargs):
                self.command=command; self.returncode=None;self.queue=deque();self.stdout=self;self.stdin=self
                self.arm=command[command.index('--worker')+1];self.width=int(command[command.index('--width')+1])
                self.fixture_sha=command[command.index('--fixture-sha')+1]
                self.library=command[command.index('--library')+1]
                self.expected=bench.numerical.raw_sha(prepared[self.width]['expected'][self.arm]);self.calls=[]
                self.cache=Path(kwargs['cwd']).resolve()
                self.assertions=all(Path(kwargs['env'][name]).is_dir() and Path(kwargs['env'][name]).is_relative_to(self.cache) for name in bench.CACHE_ENV)
                self.queue.extend(['debug retained\n',bench.PREFIX+json.dumps({'ready':True,'arm':self.arm,'width':self.width,'fixture_sha256':self.fixture_sha,'script_sha256':bench.digest(ROOT/'experiments/width-boundaries/bench_order.py'),'cache_root':str(self.cache)})+'\n'])
                created.append(self)
            def __iter__(self):return self
            def __next__(self):
                if self.queue:return self.queue.popleft()
                raise StopIteration
            def write(self,text):
                value=json.loads(text);self.calls.append(value)
                if value['command']=='quit':self.returncode=0;return
                if value['command']=='identity':response={'inputs_unchanged':True,'libraries_sha256':{self.library:bench.numerical.LIBRARY_SHA}}
                else:
                    time={'native':100.,'preordered':90.,'sort_each':110.}[self.arm]
                    response={'number':value['number'],'arm':self.arm,'width':self.width,'inputs_unchanged':True,'wall_us':time,'event_us':time,'output_sha256':self.expected}
                self.queue.append(bench.PREFIX+json.dumps(response)+'\n')
            def flush(self):pass
            def poll(self):return self.returncode
            def wait(self,timeout):return self.returncode
            def kill(self):self.returncode=-9
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);library=root/'fake.so';library.write_bytes(b'CPU fixture')
            args=types.SimpleNamespace(output=root/'output',capture=root,device_source=Path('/tmp/trt-device-op-sfa-token.py'),library=library,source_commit='CPU-fixture')
            bind=bench.numerical.bind
            def admitted(path,sha):
                if path==library:return {'path':str(path),'sha256':sha,'bytes':path.stat().st_size}
                return bind(path,sha)
            with patch.object(bench,'fixtures',return_value=prepared),patch.object(bench.numerical,'bind',side_effect=admitted),patch.object(bench.subprocess,'Popen',side_effect=Process),redirect_stdout(io.StringIO()):
                self.assertEqual(bench.benchmark(args),0)
            report=json.loads((args.output/'report.json').read_text())
            self.assertEqual(len(created),6)
            self.assertEqual(len({p.cache for p in created}),6)
            self.assertTrue(all(p.assertions for p in created))
            self.assertTrue(all(len([r for r in p.calls if r['command']=='measure'])==72 for p in created))
            self.assertTrue(all(len(value['samples'])==60 and len(value['warmup'])==12 for value in report['widths'].values()))
            self.assertFalse(report['formal_precision_gate_passed'])


if __name__=='__main__':unittest.main(verbosity=2)
