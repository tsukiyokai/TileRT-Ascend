import hashlib,itertools,json,math,statistics,tarfile
from pathlib import Path
import torch
from torch.nn import functional as F
root=Path('/tmp/trt-order-bench-readback-20261029')
root.mkdir(exist_ok=False)
with tarfile.open('/tmp/trt-sfa-order-bench-v1-raw.tar') as archive:
 for member in archive:
  if member.isfile():(root/Path(member.name).name).write_bytes(archive.extractfile(member).read())
def digest(path):
 with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()
def raw_sha(tensor):
 return hashlib.sha256(memoryview(tensor.contiguous().reshape(-1).view(torch.uint8).numpy())).hexdigest()
def stats(values):
 data=sorted(values)
 return {'p50':statistics.median(data),**{f'p{q}':data[round(q/100*(len(data)-1))] for q in (90,95,99)},'min':min(data),'max':max(data),'std':statistics.pstdev(data)}
exit=json.loads((root/'sfa-order-bench-v1-exit.json').read_text())
assert exit['docker_wait_exit']=='0' and exit['state']['ExitCode']==0 and not exit['state']['OOMKilled']
x=json.loads((root/'report.json').read_text())
assert x['status']=='measured' and x['performance_measured']
assert x['source_sha256']['bench_order.py']=='6abe305285292964c428c280a0804aec9acd5732c7fc39b78cbe40f7ed2d0574'
assert x['source_sha256']['sfa_order.py']=='321a364865dca62523fe815f5bcee1b1bcd861fa83180f4799fb4c85a92ed6a5'
assert set(x['widths'])=={'1','32'}
results={}
for width,item in x['widths'].items():
 fixture_path=root/f'inputs-width{width}.pt'
 assert digest(fixture_path)==item['fixture_sha256']
 fixture=torch.load(fixture_path,weights_only=True,map_location='cpu')
 expected={arm:raw_sha(value) for arm,value in fixture['expected'].items()}
 arms=('native','preordered','sort_each')
 orders=tuple(itertools.permutations(arms))
 assert len(item['warmup'])==12 and len(item['samples'])==60
 assert len({worker['cache_root'] for worker in item['workers'].values()})==3
 for number,row in zip(range(-12,60),item['warmup']+item['samples'],strict=True):
  assert row['number']==number and tuple(row['order'])==orders[number%6]
  for arm in arms:
   sample=row[arm];worker=item['workers'][arm]
   assert sample['number']==number and sample['arm']==arm and sample['width']==int(width)
   assert sample['inputs_unchanged'] and sample['input_fingerprints']==worker['input_fingerprints']
   assert sample['output_sha256']==expected[arm]==worker['expected_output_sha256']==worker['startup_output_sha256']
   assert worker['final_identity']['inputs_unchanged']
   for clock in ('wall_us','event_us'): assert math.isfinite(sample[clock]) and sample[clock]>0
 timing={arm:{clock:stats([row[arm][clock] for row in item['samples']]) for clock in ('wall_us','event_us')} for arm in arms}
 assert timing==item['timings']
 gates={}
 for arm in arms[1:]:
  for clock in ('wall_us','event_us'):
   values=[row['native'][clock]-row[arm][clock] for row in item['samples']]
   assert {**stats(values),'wins':sum(value>0 for value in values)}==item['paired_savings_us'][arm][clock]
  gates[arm]=all(timing[arm][clock][q]<=.95*timing['native'][clock][q] for clock in ('wall_us','event_us') for q in ('p50','p95'))
 assert gates['preordered']==item['preordered_prediction_met']
 assert gates['sort_each']==item['sort_each_including_cost_prediction_met']
 a=fixture['expected']['native'].double().reshape(int(width),-1)
 b=fixture['expected']['preordered'].double().reshape(int(width),-1)
 nrmse=((a-b).square().mean(-1)/a.square().mean(-1)).sqrt()
 cosine=F.cosine_similarity(a,b,dim=-1)
 assert bool((nrmse<=.01).all()) and bool((cosine>=.999).all())
 indices=fixture['inputs']['topk_indices']
 assert torch.equal(indices.sort(-1).values,fixture['ordered'])
 results[width]={'all_216_device_samples_match_full_frozen_outputs':True,'fixture_sha256':digest(fixture_path),'timings':timing,'predictions':gates,'preordered_vs_native':{'rows':int(width),'max_row_nrmse':float(nrmse.max()),'min_row_cosine':float(cosine.min()),'max_abs':float((a-b).abs().max()),'all_rows_within_component_tolerance':True},'paired_savings_us':item['paired_savings_us']}
output={'scope':'Independent saved actual A3 component timing and full-row output readback','raw_report_sha256':digest(root/'report.json'),'widths':results,'all_432_samples_and_statistics_verified':True,'formal_precision_gate_passed':False,'TPOT_measured':False}
Path('/tmp/trt-order-bench-independent-20261029.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output,indent=2))
