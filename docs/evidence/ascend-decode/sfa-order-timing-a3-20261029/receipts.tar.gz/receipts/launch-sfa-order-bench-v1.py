from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess


ROOT = Path('/tmp/trt-canonical-20261029-192')
NAME = 'trt-bench-01a1819b-sfa-order-bench-v1'
assert hashlib.sha256((ROOT/'receipts/sfa-order-bench-v1/bench_order.py').read_bytes()).hexdigest() == '6abe305285292964c428c280a0804aec9acd5732c7fc39b78cbe40f7ed2d0574'
assert json.loads((ROOT/'receipts/sfa-order-bench-v1-preflight-exit.json').read_text())['state']['ExitCode'] == 0
contract = {'created_at':datetime.now(timezone.utc).isoformat(),'scope':'Actual rank12 one complete SFA call; widths1/32; component only','source_commit':'aeb793074402ad3def572052d33cca327e2b987a','script_sha256':'6abe305285292964c428c280a0804aec9acd5732c7fc39b78cbe40f7ed2d0574','arms':['native','preordered','sort_each'],'prediction':'preordered p50/p95 <= .95 native on both wall and event, each width independently; sort_each complete cost reported separately','protocol':{'warmup_groups':12,'measured_groups':60,'six_order_permutations':True,'private_process_and_cache_per_arm':True,'pressure_outside_timing_bytes':268435456,'profiler':False,'graph':False,'one_complete_SFA_call':True,'clock_lock':False},'formal_precision_gate_passed':False,'TPOT_measured':False}
(ROOT/'receipts/sfa-order-bench-v1-contract.json').write_text(json.dumps(contract,indent=2)+'\n')
assert subprocess.run(['docker', 'inspect', NAME], capture_output=True).returncode != 0
ids = subprocess.check_output(['docker', 'ps', '-q'], text=True).split()
containers = json.loads(subprocess.check_output(['docker', 'inspect', *ids], text=True)) if ids else []
now = datetime.now(timezone.utc)
for container in containers:
    if container['HostConfig']['Runtime'] == 'runc' and (container['Config']['Labels'] or {}).get('trt.goal') == '01a1819b-7bc8-7eb0-b016-746bd504e995':
        continue
    started = re.sub(r'(\.\d{6})\d+Z$', r'\1+00:00', container['State']['StartedAt'])
    assert (now - datetime.fromisoformat(started)).total_seconds() >= 180, container['Name']
raw = subprocess.check_output(['npu-smi', 'info'], text=True)
board = subprocess.check_output(['npu-smi', 'info', '-t', 'board', '-i', '0', '-c', '0'], text=True)
assert '9392' in board or '9382' in board
(ROOT / 'receipts/before-sfa-order-bench-v1.txt').write_text(now.isoformat() + '\n' + raw + '\n' + board)
memory = {int(die): int(used) for die, used in re.findall(r'^\|\s*[01]\s+(\d+)\s+\|[^\n]*?(\d+)\s*/\s*65536\s*\|', raw, re.M)}
busy = {int(npu) * 2 + int(chip) for npu, chip, pid in re.findall(r'^\|\s*(\d+)\s+(\d+)\s+\|\s*(\d+)\s+\|', raw, re.M)}
free = sorted(die for die, used in memory.items() if used <= 65536 * 0.08 and die not in busy)
assert len(memory) == 16 and free
assert 12 in free
die = 12
(ROOT / 'receipts/before-sfa-order-bench-v1.txt').write_text(now.isoformat() + '\n' + raw + '\n' + board)
command = json.loads((ROOT/'receipts/resident-pair-192-v1-docker-command.json').read_text())
command[command.index('--network=host')] = '--network=none'
for i,item in enumerate(command):
    if item.startswith('ASCEND_RT_VISIBLE_DEVICES='):
        command[i]='ASCEND_RT_VISIBLE_DEVICES=0'
command[command.index('--name') + 1] = NAME
for i, item in enumerate(command):
    if item.startswith('ASCEND_VISIBLE_DEVICES='):
        command[i] = f'ASCEND_VISIBLE_DEVICES={die}'
command[-1] = '/work/receipts/sfa-order-bench-v1.sh'
(ROOT / 'receipts/sfa-order-bench-v1-docker-command.json').write_text(json.dumps(command, indent=2) + '\n')
cid = subprocess.check_output(command, text=True).strip()
(ROOT / 'receipts/sfa-order-bench-v1-container-id.txt').write_text(cid + '\n')
print(json.dumps({'container_id': cid, 'physical_die': die, 'logical_die': 0, 'free_dies_at_guard': free}))
