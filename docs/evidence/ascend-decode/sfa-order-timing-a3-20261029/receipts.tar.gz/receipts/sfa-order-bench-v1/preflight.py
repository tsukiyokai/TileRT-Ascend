import hashlib,json,sys
from pathlib import Path
sys.path.insert(0,'/work/receipts/sfa-order-bench-v1')
import bench_order as bench
assert bench.digest(Path(bench.__file__))=='6abe305285292964c428c280a0804aec9acd5732c7fc39b78cbe40f7ed2d0574'
prepared=bench.fixtures(Path('/work/evidence/width-boundaries-v1'))
result={'scope':'Actual CPU fixture admission; no NPU import or binding','widths':{}}
for width,item in prepared.items():
 result['widths'][str(width)]={'inputs':{key:{'shape':list(value.shape),'dtype':str(value.dtype),'sha256':bench.numerical.raw_sha(value)} for key,value in item['inputs'].items()},'lengths':{key:bench.numerical.length_identity(value) for key,value in item['lengths'].items()},'expected_output_sha256':{key:bench.numerical.raw_sha(value) for key,value in item['expected'].items()}}
Path('/work/receipts/sfa-order-bench-v1-preflight.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'admitted_widths':list(prepared),'npu_executed':False}))
