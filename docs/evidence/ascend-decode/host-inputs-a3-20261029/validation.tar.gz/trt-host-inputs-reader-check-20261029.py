"""Exercise the actual independent reader with saved run data and corruptions."""

import copy
import importlib.util
import json
from pathlib import Path
import unittest

ROOT = Path('/home/shanshan/repo/tile-ai/tilert-ascend')
SPEC = importlib.util.spec_from_file_location(
    'read_bench', ROOT / 'experiments/host-inputs/read_bench.py')
READER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(READER)
REPORT = json.loads(Path('/tmp/trt-host-inputs-v1-report.json').read_text())
EXIT = json.loads(Path('/tmp/trt-host-inputs-v1-exit.json').read_text())


class ReadSavedRun(unittest.TestCase):
    def reject(self, edit):
        report = copy.deepcopy(REPORT)
        edit(report)
        with self.assertRaises(ValueError):
            READER.read(report, ROOT)

    def test_actual_positive(self):
        result = READER.read(REPORT, ROOT)
        self.assertTrue(result['all_288_sample_signatures_verified'])
        self.assertEqual(
            {width: item['prediction_met'] for width, item in result['widths'].items()},
            {'1': False, '32': False})
        self.assertEqual(result['widths']['32']['timings']['separate']['wall_us']['p50'],
                         767.251)
        self.assertEqual(result['widths']['32']['timings']['packet']['wall_us']['p50'],
                         628.5165)
        self.assertEqual(READER.terminal(EXIT)['ExitCode'], 0)

    def test_same_forged_consumer_signature_both_arms(self):
        def edit(report):
            for arm in READER.ARMS:
                report['widths']['32']['samples'][0][arm]['consumer_signature'] = '0' * 64
        self.reject(edit)

    def test_changed_sample_number(self):
        self.reject(lambda report: report['widths']['1']['samples'][0]['packet']
                    .update(number=1))

    def test_missing_warmup(self):
        self.reject(lambda report: report['widths']['1']['warmup'].pop())

    def test_wrong_abba_order(self):
        self.reject(lambda report: report['widths']['1']['samples'][0]
                    .update(order=['packet', 'separate']))

    def test_address_changes(self):
        def edit(report):
            report['widths']['32']['samples'][0]['separate']['input_addresses'][0] += 256
        self.reject(edit)

    def test_wrong_packet_offset(self):
        def edit(report):
            for phase in ('warmup', 'samples'):
                for row in report['widths']['32'][phase]:
                    row['packet']['input_addresses'][1] += 8
        self.reject(edit)

    def test_nonfinite_clock(self):
        self.reject(lambda report: report['widths']['1']['samples'][0]['packet']
                    .update(event_us=float('nan')))

    def test_false_statistics(self):
        self.reject(lambda report: report['widths']['32']['paired_savings_us']['wall_us']
                    .update(p50=9999))

    def test_false_prediction(self):
        self.reject(lambda report: report['widths']['32'].update(prediction_met=True))

    def test_missing_graph_width(self):
        self.reject(lambda report: report['workers']['packet']['graph_checks'].pop())

    def test_shared_cache_root(self):
        self.reject(lambda report: report['workers']['packet']
                    .update(cache_root=report['workers']['separate']['cache_root']))

    def test_source_mismatch(self):
        def edit(report):
            for arm in READER.ARMS:
                report['workers'][arm]['source'][READER.SOURCES[0]] = '0' * 64
        self.reject(edit)

    def test_nonzero_and_boolean_worker_exit(self):
        for code in (1, False):
            with self.subTest(code=code):
                self.reject(lambda report: report['worker_exit_codes'].update(packet=code))

    def test_real_watcher_exit_failures(self):
        for field, value in (('docker_wait_exit', '1'), ('id', 'wrong')):
            receipt = copy.deepcopy(EXIT)
            receipt[field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                READER.terminal(receipt)
        receipt = copy.deepcopy(EXIT)
        receipt['state']['ExitCode'] = 1
        with self.assertRaises(ValueError):
            READER.terminal(receipt)


if __name__ == '__main__':
    unittest.main(verbosity=2)
