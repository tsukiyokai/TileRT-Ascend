export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
set -e
source /opt/ascend/cann-9.2.0/set_env.sh
source /usr/local/Ascend/nnal/atb/set_env.sh
set -u
runtime=/assets/vendor-hook-runtime212-int8
export PYTHONPATH="/work/source-host-inputs-v1:/assets/vllm-unified:/work/runtime-sfa-token:$runtime/vendor-hook-pinned/vendor-metadata:$runtime/vendor-hook-deps/transformers519:$runtime/vendor-hook-deps/python${PYTHONPATH:+:$PYTHONPATH}"
export LD_LIBRARY_PATH="/opt/openEuler/gcc-toolset-12/root/usr/lib64${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
original=/work/runtime-sfa-token/vllm_ascend/_cann_ops_custom/vendors/custom_transformer
export ASCEND_CUSTOM_OPP_PATH="/opt/kernel-overlay/vendors/custom_transformer:$original${ASCEND_CUSTOM_OPP_PATH:+:$ASCEND_CUSTOM_OPP_PATH}"
export PYTHONDONTWRITEBYTECODE=1
export VLLM_PLUGINS=ascend,ascend_model HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export HCCL_OP_EXPANSION_MODE=AIV HCCL_DETERMINISTIC=true

set +e
timeout 900 python -B /work/source-host-inputs-v1/experiments/host-inputs/bench.py --source-commit 2e41d67de8e22b82239a86bbe112f604423f2883 --output /work/evidence/host-inputs-v1 > /work/receipts/host-inputs-v1-driver.log 2>&1
status=$?
echo "$status" > /work/receipts/host-inputs-v1-exit.txt
exit "$status"
