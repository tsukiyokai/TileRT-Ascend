import hashlib,json,sys
from functools import partial
from pathlib import Path
from unittest.mock import patch
import torch
sys.path.insert(0,'/work/source-host-inputs-v1')
from tilert.models.glm_5_2_ascend import cann_model,host_inputs
expected={'cann_model.py':'7e5a9822426468b3e2b0a65da539da79536aac5d13a01c4d8047e8fd0bce47fd','host_inputs.py':'f2f2286fb43ef4dbdf09b2bff6588be69b57f39de1855f5a3363a2b6d0ef6034'}
for module in [cann_model,host_inputs]:
 p=Path(module.__file__);assert hashlib.sha256(p.read_bytes()).hexdigest()==expected[p.name]
checks=[]
with patch.object(torch.Tensor,'pin_memory',lambda self:self),patch.object(host_inputs,'HostInputs',partial(host_inputs.HostInputs,pin_memory=False)):
 for packet in [False,True]:
  engine=cann_model.CannModel.__new__(cann_model.CannModel)
  engine.device=torch.device('cpu');engine.layout={'capacity_tokens':9344};engine.capacity=9344
  engine.packed_host_inputs=packet;engine.attention_kernel='sfa';engine.graph_width=32;engine.hoist_metadata=False;engine.builders=[]
  engine._allocate_inputs()
  for width in [1,2,4,6,8,12,16,24,32]:
   for mode in ['host','tensor','mixed']:
    engine.position=8192
    values=list(range(500,500+width))
    tokens=values if mode=='host' else (torch.tensor(values) if mode=='tensor' else [torch.tensor(v) if i%2==0 else v for i,v in enumerate(values)])
    depths=tuple(i//2 for i in range(width))
    actual_width,metadata=engine._prepare_inputs(tokens,depths=depths)
    actual=[engine.input_ids.tolist(),engine.positions.tolist(),engine.slots.tolist(),engine.seq_lens.tolist()]
    want=[values,[8192+d for d in depths],list(range(8192,8192+width)),[8192+width]]
    assert actual_width==width and metadata=={} and actual==want,(packet,width,mode,actual)
    checks.append({'packet':packet,'width':width,'mode':mode,'exact':True})
result={'scope':'Real CannModel input path with actual vendor common metadata on CPU; pin disabled; no NPU binding','checks':checks,'source_sha256':expected,'all_passed':True}
Path('/work/receipts/host-inputs-v1-preflight.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'all_passed':True}))
