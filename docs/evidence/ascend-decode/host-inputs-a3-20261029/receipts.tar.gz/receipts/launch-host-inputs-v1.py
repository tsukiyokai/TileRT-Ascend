from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess


ROOT = Path('/tmp/trt-canonical-20261029-192')
NAME = 'trt-bench-01a1819b-host-inputs-v1'
assert hashlib.sha256((ROOT/'source-host-inputs-v1/experiments/host-inputs/bench.py').read_bytes()).hexdigest() == '8f190b3665a084c5c44d6157bd920294665b7f654e37250f83de48ef85a5cff7'
(ROOT/'receipts/host-inputs-v1-contract.json').write_text(json.dumps({'scope': 'Actual CannModel._prepare_inputs plus CommonMetadata; no vendor builders/model/TP', 'physical_prediction': 'One packed pinned H2D replaces separately prepared token/length/slot/position transfers; width32 wall/event p50<=.8 control, p95 no regression', 'protocol': {'warmup_pairs': 12, 'measured_pairs': 60, 'orders': 'alternating AB/BA', 'private_workers_and_caches': True, 'pressure_outside_timing_bytes': 268435456, 'graph_correctness_all_9_widths_32_queued_replays': True, 'graph_in_timing': False, 'profiler': False, 'clock_lock': False}, 'source_sha256': {'cann_model.py': '7e5a9822426468b3e2b0a65da539da79536aac5d13a01c4d8047e8fd0bce47fd', 'host_inputs.py': 'f2f2286fb43ef4dbdf09b2bff6588be69b57f39de1855f5a3363a2b6d0ef6034', 'bench.py': '8f190b3665a084c5c44d6157bd920294665b7f654e37250f83de48ef85a5cff7'}, 'CPU_checks': '6 HostInputs unit and 7 token staging pass; actual vendor import in device-free runc requires Triton NPU arch, so real metadata admission moves to guarded A3', 'TPOT_measured': False, 'formal_precision_gate_passed': False},indent=2)+'\n')
assert subprocess.run(['docker', 'inspect', NAME], capture_output=True).returncode != 0
ids = subprocess.check_output(['docker', 'ps', '-q'], text=True).split()
containers = json.loads(subprocess.check_output(['docker', 'inspect', *ids], text=True)) if ids else []
now = datetime.now(timezone.utc)
for container in containers:
    if container['HostConfig']['Runtime'] == 'runc' and (container['Config']['Labels'] or {}).get('trt.goal') == '01a1819b-7bc8-7eb0-b016-746bd504e995':
        continue
    started = re.sub(r'(\.\d{6})\d+Z$', r'\1+00:00', container['State']['StartedAt'])
    assert (now - datetime.fromisoformat(started)).total_seconds() >= 180, container['Name']
raw = subprocess.check_output(['npu-smi', 'info'], text=True)
board = subprocess.check_output(['npu-smi', 'info', '-t', 'board', '-i', '0', '-c', '0'], text=True)
assert '9392' in board or '9382' in board
(ROOT / 'receipts/before-host-inputs-v1.txt').write_text(now.isoformat() + '\n' + raw + '\n' + board)
memory = {int(die): int(used) for die, used in re.findall(r'^\|\s*[01]\s+(\d+)\s+\|[^\n]*?(\d+)\s*/\s*65536\s*\|', raw, re.M)}
busy = {int(npu) * 2 + int(chip) for npu, chip, pid in re.findall(r'^\|\s*(\d+)\s+(\d+)\s+\|\s*(\d+)\s+\|', raw, re.M)}
free = sorted(die for die, used in memory.items() if used <= 65536 * 0.08 and die not in busy)
assert len(memory) == 16 and free
assert 12 in free
die = 12
(ROOT / 'receipts/before-host-inputs-v1.txt').write_text(now.isoformat() + '\n' + raw + '\n' + board)
command = json.loads((ROOT/'receipts/resident-pair-192-v1-docker-command.json').read_text())
command[command.index('--network=host')] = '--network=none'
for i,item in enumerate(command):
    if item.startswith('ASCEND_RT_VISIBLE_DEVICES='):
        command[i]='ASCEND_RT_VISIBLE_DEVICES=0'
command[command.index('--name') + 1] = NAME
for i, item in enumerate(command):
    if item.startswith('ASCEND_VISIBLE_DEVICES='):
        command[i] = f'ASCEND_VISIBLE_DEVICES={die}'
command[-1] = '/work/receipts/host-inputs-v1.sh'
(ROOT / 'receipts/host-inputs-v1-docker-command.json').write_text(json.dumps(command, indent=2) + '\n')
cid = subprocess.check_output(command, text=True).strip()
(ROOT / 'receipts/host-inputs-v1-container-id.txt').write_text(cid + '\n')
print(json.dumps({'container_id': cid, 'physical_die': die, 'logical_die': 0, 'free_dies_at_guard': free}))
