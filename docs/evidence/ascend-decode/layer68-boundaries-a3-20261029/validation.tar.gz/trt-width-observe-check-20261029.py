"""stdlib-only integration of the real observer, route hook and capture_mlp."""
import copy
import importlib.util
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path('/home/shanshan/repo/tile-ai/tilert-ascend')
sys.path.insert(0, str(ROOT / 'tests/glm52'))
import run_cann_model as legacy


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


routes = load('routes', ROOT / 'experiments/layer0-boundaries/routes.py')
observer = load('observer', ROOT / 'experiments/width-boundaries/observe.py')


class Tensor:
    def __init__(self, value, shape=(1, 4), dtype='float32'):
        self.value = value
        self.shape = shape
        self.dtype = dtype
        self.device = 'fake:0'

    def detach(self):
        return self

    def clone(self):
        return Tensor(copy.deepcopy(self.value), self.shape, self.dtype)


class Handle:
    def __init__(self, hooks, key):
        self.hooks, self.key = hooks, key

    def remove(self):
        self.hooks.pop(self.key, None)


class Module:
    def __init__(self, function):
        self.function = function
        self.pre, self.post = {}, {}
        self.index = 0

    def register_forward_pre_hook(self, hook, with_kwargs=False):
        self.index += 1
        self.pre[self.index] = (hook, with_kwargs)
        return Handle(self.pre, self.index)

    def register_forward_hook(self, hook, with_kwargs=False, always_call=False):
        self.index += 1
        self.post[self.index] = (hook, with_kwargs, always_call)
        return Handle(self.post, self.index)

    def __call__(self, *args, **kwargs):
        for hook, named in list(self.pre.values()):
            hook(self, args, kwargs) if named else hook(self, args)
        try:
            output = self.function(*args, **kwargs)
        except BaseException:
            for hook, named, always in list(self.post.values()):
                if always:
                    hook(self, args, kwargs, None) if named else hook(self, args, None)
            raise
        for hook, named, always in list(self.post.values()):
            hook(self, args, kwargs, output) if named else hook(self, args, output)
        return output


class Router:
    top_k = 8
    eplb_state = None


class Routed:
    router = Router()
    log2phy = None

    def _select_experts(self, hidden_states, router_logits, force, input_ids=None):
        self.seen_ids = input_ids
        return Tensor('weights'), Tensor('ids')


class Dispatcher:
    def token_combine(self, hidden_states, metadata, bias=None):
        return hidden_states


class Scheme:
    def __init__(self, dispatcher):
        self.dispatcher = dispatcher

    def apply_gmm1_act_quant(self, value):
        return Tensor('fused-a8'), Tensor('fused-scale')

    def apply_gmm2(self, value, hidden_states, act_out_scale):
        return Tensor('gmm2')

    def apply(self, *, hidden_states, topk_weights, topk_ids):
        dispatch = types.SimpleNamespace(group_list_type=1, hidden_states=Tensor('dispatch-a8'),
            dynamic_scale=Tensor('dispatch-scale'), group_list=Tensor('counts'))
        act, scale = self.apply_gmm1_act_quant(dispatch)
        down = self.apply_gmm2(dispatch, act, scale)
        metadata = types.SimpleNamespace(restore_shape=hidden_states.shape,
            expanded_row_idx=Tensor('row-idx'), topk_weights=topk_weights)
        return self.dispatcher.token_combine(down, metadata)


class Runner:
    def __init__(self, scheme):
        self.routed_experts = Routed()
        self.routed_experts.quant_method = types.SimpleNamespace(quant_method=scheme)
        self.moe_config = 'actual-fake-config'

    def _forward_impl(self, hidden_states):
        weights, ids = self.routed_experts._select_experts(hidden_states, Tensor('logits'), False)
        routed = self.routed_experts.quant_method.quant_method.apply(
            hidden_states=hidden_states, topk_weights=weights, topk_ids=ids)
        return Tensor('shared'), routed


class Sfa:
    scale = 0.0625
    W_UV = Tensor('UV')

    def _execute_sparse_flash_attention_process(self, ql_nope, q_pe, kv_cache,
            topk_indices, attn_metadata, actual_seq_lengths_query,
            actual_seq_lengths_key, block_table=None):
        self.seen = (ql_nope, q_pe, kv_cache, topk_indices, attn_metadata,
                     actual_seq_lengths_query, actual_seq_lengths_key, block_table)
        if self.fail:
            raise RuntimeError('SFA failed')
        return self.output


class Engine:
    def _tp_sum_original(self, value):
        self.reduce_seen.append(value)
        return value

    def __init__(self):
        self.reduce_seen = []
        self.dispatcher = Dispatcher()
        self.scheme = Scheme(self.dispatcher)
        self.runner = Runner(self.scheme)
        self.impl = Sfa()
        self.impl.fail = False
        self.impl.output = Tensor('SFA-output')
        self.explicit_table = Tensor('explicit-table')
        self.default_table = Tensor('default-table')
        self.attn_meta = types.SimpleNamespace(block_table=self.default_table)
        self.input_norm = Module(lambda hidden_states, residual: (Tensor('input-normalized'), residual))
        self.post_norm = Module(lambda hidden_states, residual: (Tensor('post-normalized'), residual))
        self.norm69 = Module(lambda hidden_states, residual: (Tensor('norm69-normalized'), residual))
        self.attention = Module(self.attention_forward)
        self.attention.mla_attn = types.SimpleNamespace(mla_attn=types.SimpleNamespace(impl=self.impl))
        self.mlp = Module(self.mlp_forward)
        self.mlp.experts = self.runner
        self.layer = Module(self.layer_forward)
        self.layer.input_layernorm = self.input_norm
        self.layer.post_attention_layernorm = self.post_norm
        self.layer.self_attn = self.attention
        self.layer.mlp = self.mlp
        self.model = types.SimpleNamespace(model=types.SimpleNamespace(
            layers=[None] * 68 + [self.layer, types.SimpleNamespace(input_layernorm=self.norm69)]))

    def attention_forward(self, hidden_states):
        output = self.impl._execute_sparse_flash_attention_process(
            hidden_states, Tensor('qpe'), (Tensor('KV'), Tensor('rope')), Tensor('indices'),
            self.attn_meta, Tensor('query-lengths'), Tensor('key-lengths'),
            block_table=self.explicit_table)
        self._tp_sum_original(Tensor('attn-partial-1'))
        self._tp_sum_original(Tensor('attn-partial-2'))
        return output

    def mlp_forward(self, hidden_states):
        shared, routed = self.runner._forward_impl(hidden_states)
        self._tp_sum_original(Tensor('mlp-partial'))
        return routed

    def layer_forward(self, *, hidden_states, residual, positions):
        normalized, retained = self.input_norm(hidden_states, residual)
        attention = self.attention(normalized)
        normalized, retained = self.post_norm(attention, retained)
        return self.mlp(normalized), retained

    def forward(self):
        hidden, retained = self.layer(hidden_states=Tensor('in-hidden'), residual=Tensor('residual'),
                                     positions=Tensor('positions'))
        self.norm69(hidden, retained)
        return hidden, retained

    def assert_restored(self, testcase):
        for target in (self.layer, self.input_norm, self.post_norm, self.attention, self.mlp, self.norm69):
            testcase.assertEqual((target.pre, target.post), ({}, {}))
        for target, names in ((self, ['_tp_sum_original']),
                (self.impl, ['_execute_sparse_flash_attention_process']),
                (self.runner, ['_forward_impl']), (self.runner.routed_experts, ['_select_experts']),
                (self.scheme, ['apply', 'apply_gmm1_act_quant', 'apply_gmm2']),
                (self.dispatcher, ['token_combine'])):
            for name in names:
                testcase.assertNotIn(name, vars(target))


def dependencies(engine):
    config = types.ModuleType('vllm_ascend.ascend_config')
    config.get_ascend_config = lambda: types.SimpleNamespace(enable_force_eplb=False)
    context = types.ModuleType('vllm_ascend.ascend_forward_context')
    context._EXTRA_CTX = types.SimpleNamespace(in_profile_run=False)
    comm = types.ModuleType('vllm_ascend.ops.fused_moe.moe_comm_method')
    comm.MoECommType = types.SimpleNamespace(ALLGATHER='allgather')
    comm.get_moe_comm_method = lambda kind, config: types.SimpleNamespace(token_dispatcher=engine.dispatcher)
    return {'torch': types.SimpleNamespace(Tensor=Tensor, float32='float32'),
            'routes': routes, 'run_cann_model': legacy,
            config.__name__: config, context.__name__: context, comm.__name__: comm}


class Observe(unittest.TestCase):
    def test_actual_observer_and_frozen_helpers_keep_all_fp32_calls_and_owned_data(self):
        engine = Engine()
        with patch.dict(sys.modules, dependencies(engine)):
            with observer.observe(engine) as observed:
                output = engine.forward()
                self.assertEqual(output[0].value, 'gmm2')
                self.assertIs(engine.impl.seen[-1], engine.explicit_table)
                extra = engine.impl._execute_sparse_flash_attention_process(
                    Tensor('ql'), Tensor('qpe'), (Tensor('KV'), Tensor('rope')),
                    Tensor('indices'), engine.attn_meta, [1], [8206])
                self.assertIs(extra, engine.impl.output)
                self.assertIsNone(engine.impl.seen[-1])
            engine.assert_restored(self)
        self.assertEqual([item['phase'] for item in observed['metadata']['tp_calls']],
                         ['attention', 'attention', 'mlp'])
        values = observed['tensors']
        self.assertEqual(values['layer68.forward.call0.kwargs.positions'].value, 'positions')
        self.assertEqual(values['layer68.input_norm.call0.in.1'].value, 'residual')
        self.assertEqual(values['layer69.input_norm.call0.out.1'].value, 'residual')
        self.assertEqual(values['layer68.sfa.call0.block_table'].value, 'explicit-table')
        self.assertEqual(values['layer68.sfa.call0.W_UV'].value, 'UV')
        self.assertEqual(values['layer68.sfa.call1.block_table'].value, 'default-table')
        self.assertEqual(observed['metadata']['scalar_values']['layer68.sfa.call1.actual_seq_lengths_query.0'], 1)
        self.assertEqual(observed['metadata']['scalar_values']['layer68.sfa.call1.actual_seq_lengths_key.0'], 8206)
        self.assertEqual(set(observed['moe_stages']), {'input', 'output', 'probs_fp32', 'topk_ids',
            'dispatch_a8', 'dispatch_scale', 'group_counts', 'fused_a8', 'fused_scale',
            'gmm2_group_counts', 'down', 'expanded_row_idx', 'finalize_probs_fp32',
            'finalize', 'combine', 'shared'})
        self.assertEqual(observed['routes'][0]['router_logits'].value, 'logits')
        engine.impl.output.value = 'mutated-after-return'
        self.assertEqual(values['layer68.sfa.call0.out'].value, 'SFA-output')
        self.assertEqual(observed['metadata']['call_counts']['layer68.tp.attention'], 2)

    def test_device_call_failure_and_body_failure_restore_every_patch(self):
        for fail_in_sfa in (True, False):
            engine = Engine()
            engine.impl.fail = fail_in_sfa
            with patch.dict(sys.modules, dependencies(engine)), self.assertRaises(RuntimeError):
                with observer.observe(engine):
                    engine.forward()
                    raise RuntimeError('body failed')
            engine.assert_restored(self)

    def test_partial_install_failure_restores_previously_installed_hooks_and_methods(self):
        engine = Engine()
        def rejected(layer, samples):
            raise RuntimeError('route installation failed')
        with patch.dict(sys.modules, dependencies(engine)), patch.object(routes, 'install_routes', rejected), self.assertRaisesRegex(RuntimeError, 'route installation failed'):
            with observer.observe(engine):
                self.fail('unexpected body')
        engine.assert_restored(self)


if __name__ == '__main__':
    unittest.main(verbosity=2)
