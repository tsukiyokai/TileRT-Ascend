import copy
import importlib.util
import io
import json
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import patch

import torch

ROOT = Path('/home/shanshan/repo/tile-ai/tilert-ascend')
sys.path.insert(0, str(ROOT / 'experiments/cann-precision'))


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


reader = load('reader', ROOT / 'experiments/width-boundaries/read.py')
fixtures = load('fixtures', ROOT / 'experiments/width-boundaries/check_run.py')
torch.set_num_threads(2)


def frame(mode, phase, tokens):
    guards = fixtures.RunnerChecks()
    guards.setUp()
    try:
        engine = fixtures.Engine()
        engine.position = 8205 if phase == 'serial' else 8192
        ids = [tokens[13]] if phase == 'serial' else tokens
        value = fixtures.RUN.forward(engine, ids, mode, capture=True)
    finally:
        guards.doCleanups()
    width = len(ids)
    value.update(position=8205 if phase == 'serial' else 8192,
                 committed_position=8206 if phase == 'serial' else 8224)
    if phase == 'serial':
        value['token'] = ids[0]
        value['history'] = [{'latent': torch.zeros(1, 512, dtype=torch.bfloat16),
                             'rope': torch.zeros(1, 64, dtype=torch.bfloat16)} for _ in range(14)]
    else:
        value['tokens'] = tokens
        value['new_cache'] = {'latent': torch.zeros(32, 512, dtype=torch.bfloat16),
                              'rope': torch.zeros(32, 64, dtype=torch.bfloat16)}
    observed = value['observed']
    tensors = observed['tensors']
    # Frozen Deepseek decoder calls (positions, hidden_states, residual).
    tensors['layer68.forward.call0.in.0'] = value['model_inputs']['positions'].clone()
    tensors['layer68.forward.call0.in.1'] = tensors['layer68.input_norm.call0.in.0'].clone()
    tensors['layer68.forward.call0.in.2'] = tensors['layer68.input_norm.call0.in.1'].clone()
    tensors['layer68.sfa.call0.kv_cache.0'] = torch.zeros(1, 1, 1, 512, dtype=torch.bfloat16).expand(73, 128, 1, 512)
    tensors['layer68.sfa.call0.kv_cache.1'] = torch.zeros(1, 1, 1, 64, dtype=torch.bfloat16).expand(73, 128, 1, 64)
    tensors['layer68.sfa.call0.block_table'] = torch.arange(73, dtype=torch.int32).reshape(1, -1)
    unsorted = torch.arange(2048, dtype=torch.int32).flip(0).reshape(1, 1, -1).expand(width, 1, -1)
    tensors['layer68.sfa.call0.topk_indices'] = unsorted if mode != 'sorted' else unsorted.sort(-1).values
    if mode != 'original':
        tensors['intervention.original_indices'] = unsorted.clone()
    observed['metadata']['source_sha256'] = {'/frozen' + key: sha for key, sha in reader.OBSERVED_SOURCES.items()}
    for key, tensor in tensors.items():
        if not key.startswith('intervention.'):
            observed['metadata']['tensor_layouts'][key] = {'shape': list(tensor.shape), 'dtype': str(tensor.dtype), 'device': 'npu:0'}
    observed['coverage'] = dict.fromkeys(('modules_once','actual_fp32_tp_both_phases','one_actual_router','complete_moe_stages'), True)
    for key in ('shared', 'finalize', 'combine'):
        observed['moe_stages'][key] = observed['moe_stages']['output'].clone()
    for key in ('expanded_row_idx','finalize_probs_fp32','probs_fp32','topk_ids','dispatch_a8','dispatch_scale',
                'group_counts','fused_a8','fused_scale','gmm2_group_counts','down'):
        observed['moe_stages'][key] = torch.zeros(width * 8, 4)
    return value


class Readback(unittest.TestCase):
    def test_logical_kv_respects_page_table_and_ignores_padding(self):
        cache = torch.arange(73 * 128 * 512, dtype=torch.float32).reshape(73, 128, 1, 512).bfloat16()
        table = torch.arange(73, dtype=torch.int32).flip(0).reshape(1, -1)
        saved = {'observed': {'tensors': {'layer68.sfa.call0.kv_cache.0': cache,
                                        'layer68.sfa.call0.block_table': table}}}
        actual = reader.logical_kv(saved, 0)
        logical = torch.arange(8206)
        expected = cache.reshape(-1, 512).index_select(0, table[0].long()[logical // 128] * 128 + logical % 128)
        self.assertTrue(torch.equal(actual, expected))
        baseline = actual.clone()
        cache[0].fill_(float('nan'))  # Unmapped padding page.
        self.assertTrue(torch.equal(reader.logical_kv(saved, 0), baseline))
        table[0, 0] = -1
        with self.assertRaisesRegex(ValueError, 'Page table'):
            reader.logical_kv(saved, 0)

    def test_dispatch_is_not_sliced_as_batch_and_floating_boundary_is_separate(self):
        tokens = list(range(32)); tokens[13] = 24187
        serial, wide = frame('original','serial',tokens), frame('original','wide',tokens)
        wide['observed']['tensors']['layer68.sfa.call0.topk_indices'] = wide['observed']['tensors']['layer68.sfa.call0.topk_indices'].clone()
        wide['observed']['tensors']['layer68.sfa.call0.topk_indices'][13, 0, :2] = torch.tensor([2046,2047])
        wide['observed']['tensors']['layer69.input_norm.call0.out.1'][13,0] = 1
        result = reader.comparison(wide, serial)
        self.assertEqual(result['first_bit_difference']['boundary'], 'SFA.inputs')
        self.assertEqual(result['first_floating_bit_difference']['boundary'], 'norm69.outputs')
        self.assertEqual(result['expanded_dispatch']['wide']['fused_a8']['shape'], [256,4])
        self.assertEqual(result['expanded_dispatch']['serial']['fused_a8']['shape'], [8,4])
        self.assertFalse(any('dispatch_a8' in group['fields'] for group in result['groups']))

    def test_intervention_validation_catches_wrong_actual_order(self):
        tokens = list(range(32)); tokens[13] = 24187
        value = frame('sorted','wide',tokens)
        self.assertFalse(reader.validate(value,tokens,'wide','sorted',0))
        value['observed']['tensors']['layer68.sfa.call0.topk_indices'] = value['observed']['tensors']['intervention.original_indices']
        with self.assertRaisesRegex(ValueError,'declared intervention'):
            reader.validate(value,tokens,'wide','sorted',0)

    def test_exit_one_is_diagnostic_failure_not_precision_and_unknown_is_distinct(self):
        with tempfile.TemporaryDirectory() as tmp:
            capture = Path(tmp) / 'evidence/capture'
            capture.mkdir(parents=True)
            receipts = Path(tmp) / 'receipts'; receipts.mkdir()
            self.assertEqual(reader.exit_receipts(capture)['status'], 'producer_exit_unknown')
            (receipts / 'width-boundaries-v1-exit.txt').write_text('1\n')
            (receipts / 'width-boundaries-v1-exit.json').write_text(json.dumps({'id': reader.CID,
                'docker_wait_exit': '1', 'state': {'Status':'exited','Running':False,'ExitCode':1}}))
            result = reader.exit_receipts(capture)
            self.assertEqual(result['status'],'producer_exited')
            self.assertTrue(result['capture_fail'])

    def test_full_mmap_cli_binds_16_reports_144_pt_and_never_upgrades_exit_one(self):
        tokens = list(range(32)); tokens[13] = 24187
        frames = {f'{mode}-{phase}': frame(mode,phase,tokens) for mode in reader.MODES for phase in reader.PHASES}
        def ref_view(value):
            tensors = value['observed']['tensors']
            return {**value['outputs'], 'h68': tensors['layer68.input_norm.call0.out.1'],
                    'h69': tensors['layer69.input_norm.call0.out.1'], 'indices': reader.indices(value),
                    'routes': value['observed']['routes'][0]['ids']}
        reference = {'teacher_tokens': tokens, 'checkpoint_sha256': {'fixture': 'CPU-only'},
                     'serial_target': ref_view(frames['original-serial']), 'wide': ref_view(frames['original-wide'])}
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); capture = root / 'evidence/capture'; capture.mkdir(parents=True)
            reference_path = root / 'reference.pt'; torch.save(reference,reference_path)
            reference_sha = reader.digest(reference_path)
            summary_rows = []
            for rank in range(16):
                directory = capture / f'rank-{rank}'; directory.mkdir()
                hashes, states = {}, {}
                for label, value in frames.items():
                    value = copy.deepcopy(value)
                    for layout in value['observed']['metadata']['tensor_layouts'].values():
                        layout['device'] = f'npu:{rank}'
                    path = directory / (label + '.pt'); torch.save(value,path)
                    hashes[path.name] = reader.digest(path)
                    states[label.replace('-', '.')] = reader.global_state(value)
                report = {'rank':rank,'status':'fail','source_commit':'8a2d3d89be6570cf69ad31596b142d710f7c1b42',
                    'reference_sha256':reference_sha,'teacher_sha256':reader.frozen.TEACHER_SHA256,
                    'checkpoint_sha256':reference['checkpoint_sha256'],'inputs':{'initial_position':8192},
                    'trace_sha256':hashes,'formal_precision_gate_passed':False,'performance_measured':False,
                    'source_sha256':{'/frozen'+key:sha for key,sha in reader.SOURCES.items()},
                    'packages':{'torch':'CPU-fixture'},'checks':[{'name':'explicit-failure','passed':False}]}
                path = capture / f'rank-{rank}.json'; path.write_text(json.dumps(report))
                summary_rows.append({'rank':rank,'passed':False,'report_sha256':reader.digest(path),'states':states})
            (capture / 'summary.json').write_text(json.dumps({'status':'fail','ranks':summary_rows,
                'all_rank_global_states_agree':True,'formal_precision_gate_passed':False,'performance_measured':False}))
            receipt_dir = root / 'receipts'; receipt_dir.mkdir()
            (receipt_dir / 'width-boundaries-v1-exit.txt').write_text('1\n')
            (receipt_dir / 'width-boundaries-v1-exit.json').write_text(json.dumps({'id':reader.CID,
                'docker_wait_exit':'1','state':{'Status':'exited','Running':False,'ExitCode':1}}))
            output = root / 'read.json'
            argv = ['read.py','--capture',str(capture),'--reference',str(reference_path),'--output',str(output)]
            with patch.object(reader,'REFERENCE_SHA',reference_sha), patch.object(sys,'argv',argv), redirect_stdout(io.StringIO()):
                reader.main()
            result = json.loads(output.read_text())
            self.assertTrue(result['capture_fail'])
            self.assertFalse(result['formal_precision_gate_passed'])
            self.assertEqual(len(result['ranks']),16)
            self.assertTrue(all(len(rank['raw_identities'])==9 for rank in result['ranks']))
            self.assertEqual(result['h69_bit_exact_rank_counts']['sorted'],16)
            # A complete, zero-exit synthetic capture is diagnostically valid,
            # while formal precision/performance authority remains false.
            check_names = {f'{mode}-{phase}.observation_coverage' for mode in reader.MODES for phase in reader.PHASES}
            check_names.update(f'{mode}.reset_exact' for mode in reader.MODES)
            check_names.update(('original.serial_first','original.serial_predictions','original.serial_target','original.wide'))
            for mode in reader.MODES:
                for phase in reader.PHASES:
                    for layer in range(78):
                        fields = ['latent','rope']
                        if layer < 3 or (layer-2)%4 == 0: fields.append('index_keys')
                        if 6 <= layer <= 66 and (layer-2)%4 == 0: fields.append('index_scales')
                        check_names.update(f'{mode}.{phase}.prefix.{layer}.{field}' for field in fields)
            for item in summary_rows:
                path = capture / f"rank-{item['rank']}.json"
                report = json.loads(path.read_text())
                report['status'] = 'captured'
                report['checks'] = [{'name':name,'passed':True} for name in sorted(check_names)]
                path.write_text(json.dumps(report))
                item.update(passed=True,report_sha256=reader.digest(path))
            (capture / 'summary.json').write_text(json.dumps({'status':'captured','ranks':summary_rows,
                'all_rank_global_states_agree':True,'formal_precision_gate_passed':False,'performance_measured':False}))
            (receipt_dir / 'width-boundaries-v1-exit.txt').write_text('0\n')
            (receipt_dir / 'width-boundaries-v1-exit.json').write_text(json.dumps({'id':reader.CID,
                'docker_wait_exit':'0','state':{'Status':'exited','Running':False,'ExitCode':0}}))
            with patch.object(reader,'REFERENCE_SHA',reference_sha), patch.object(sys,'argv',argv), redirect_stdout(io.StringIO()):
                reader.main()
            result = json.loads(output.read_text())
            self.assertFalse(result['capture_fail'])
            self.assertFalse(result['formal_precision_gate_passed'])
            self.assertFalse(result['performance_measured'])
            # Altered raw bytes are rejected before mmap; no silent skip.
            with (capture/'rank-0/original-serial.pt').open('ab') as stream: stream.write(b'changed')
            with patch.object(reader,'REFERENCE_SHA',reference_sha), patch.object(sys,'argv',argv), self.assertRaisesRegex(ValueError,'SHA256 mismatch'):
                reader.main()


if __name__ == '__main__':
    unittest.main(verbosity=2)
