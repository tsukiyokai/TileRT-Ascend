#!/bin/bash
set -e
exec /work/tools/strace/usr/bin/strace --seccomp-bpf -f -e trace=openat -o "/work/receipts/width-boundaries-v1-rank-${RANK}-strace.log" python -B /work/receipts/width-boundaries-v1/run.py "$@"
