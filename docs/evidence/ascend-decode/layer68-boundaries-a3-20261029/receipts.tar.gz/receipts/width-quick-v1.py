import torch,json
from pathlib import Path
torch.set_num_threads(2)
r=Path('/work/evidence/width-boundaries-v1/rank-0')
for mode in ['original','copy','sorted']:
 a=torch.load(r/(mode+'-serial.pt'),weights_only=True,map_location='cpu',mmap=True)
 b=torch.load(r/(mode+'-wide.pt'),weights_only=True,map_location='cpu',mmap=True)
 rows=[]
 for key,value in a['observed']['tensors'].items():
  other=b['observed']['tensors'].get(key)
  if not (isinstance(other,torch.Tensor) and value.ndim and value.shape[0]==1 and other.shape[0]==32 and value.shape[1:]==other.shape[1:]):continue
  selected=other[13:14]
  rows.append({'key':key,'exact':torch.equal(value,selected),'nrmse':float((value.float()-selected.float()).norm()/value.float().norm().clamp_min(1e-12))})
 stages={}
 for key in ['input','shared','combine','finalize','output','probs_fp32','topk_ids']:
  value=a['observed']['moe_stages'][key];other=b['observed']['moe_stages'][key]
  if value.ndim and value.shape[0]==1 and other.shape[0]==32 and value.shape[1:]==other.shape[1:]:
   stages[key]={'exact':torch.equal(value,other[13:14]),'nrmse':float((value.float()-other[13:14].float()).norm()/value.float().norm().clamp_min(1e-12))}
 print(json.dumps({'mode':mode,'rows':rows,'moe':stages}),flush=True)
