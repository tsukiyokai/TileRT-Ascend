set -e
export TORCH_DEVICE_BACKEND_AUTOLOAD=0
source /opt/ascend/cann-9.2.0/set_env.sh
source /usr/local/Ascend/nnal/atb/set_env.sh
set -u
export PYTHONPATH=/work/source-layer0-v1${PYTHONPATH:+:$PYTHONPATH}
export LD_LIBRARY_PATH=/opt/openEuler/gcc-toolset-12/root/usr/lib64${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}
export PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=8 MKL_NUM_THREADS=8
export ASCEND_CUSTOM_OPP_PATH=/opt/kernel-overlay/vendors/custom_transformer:/work/runtime-sfa-token/vllm_ascend/_cann_ops_custom/vendors/custom_transformer${ASCEND_CUSTOM_OPP_PATH:+:$ASCEND_CUSTOM_OPP_PATH}
export ASCEND_GLOBAL_LOG_LEVEL=3 ASCEND_SLOG_PRINT_TO_STDOUT=0
set +e
timeout 600 python -B /work/receipts/sfa-order-v1/sfa_order.py --capture /work/evidence/width-boundaries-v1 --device-source /work/runtime-sfa-token/vllm_ascend/device/device_op.py --library /assets/vllm-ascend-unified/vllm_ascend/vllm_ascend_C.cpython-311-aarch64-linux-gnu.so --output /work/evidence/sfa-order-v1 > /work/receipts/sfa-order-v1-driver.log 2>&1
status=$?
echo "$status" > /work/receipts/sfa-order-v1-exit.txt
exit "$status"
