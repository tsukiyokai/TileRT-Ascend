import copy
import importlib.util
import io
import json
import sys
import tempfile
import types
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import patch

import torch

ROOT = Path('/home/shanshan/repo/tile-ai/tilert-ascend')
spec = importlib.util.spec_from_file_location('sfa_order', ROOT/'experiments/width-boundaries/sfa_order.py')
unit = importlib.util.module_from_spec(spec); spec.loader.exec_module(unit)
torch.set_num_threads(2)


def frame(wide=False, sorted_arm=False):
    width = 32 if wide else 1
    tensors = {
        unit.PREFIX+'ql_nope': torch.zeros(width,4,512,dtype=torch.bfloat16),
        unit.PREFIX+'q_pe': torch.zeros(width,4,64,dtype=torch.bfloat16),
        unit.PREFIX+'kv_cache.0': torch.zeros(1,1,1,512,dtype=torch.bfloat16).expand(73,128,1,512),
        unit.PREFIX+'kv_cache.1': torch.zeros(1,1,1,64,dtype=torch.bfloat16).expand(73,128,1,64),
        unit.PREFIX+'block_table': torch.arange(73,dtype=torch.int32).reshape(1,-1),
        unit.PREFIX+'actual_seq_lengths_query':torch.tensor([width],dtype=torch.int32),
        unit.PREFIX+'actual_seq_lengths_key':torch.tensor([8224 if wide else 8206],dtype=torch.int32),
        unit.PREFIX+'out':torch.full((width,4,512),2 if sorted_arm else 1 if wide else 0,dtype=torch.bfloat16),
    }
    indices=torch.arange(2048,dtype=torch.int32).flip(0).reshape(1,1,-1).repeat(width,1,1)
    if wide:
        indices[13,0,[1479,1531]]=indices[13,0,[1531,1479]]
    if sorted_arm:
        tensors['intervention.original_indices']=indices.clone()
        indices=indices.sort(-1).values
    tensors[unit.PREFIX+'topk_indices']=indices
    start = 8192 if wide else 8205
    tokens = list(range(32)) if wide else [24187]
    if wide: tokens[13] = 24187
    identity = {'position': start, 'committed_position':start+width,
                'model_inputs':{name:torch.tensor(value) for name,value in {
                    'input_ids':tokens,'positions':list(range(start,start+width)),
                    'slots':list(range(start,start+width)),'query_cpu':[0,width],
                    'seq_lens':[start+width]}.items()}}
    identity['tokens' if wide else 'token'] = tokens if wide else tokens[0]
    return {**identity,'observed':{'tensors':tensors,'coverage':{'fixture':True},'metadata':{
        'source_sha256':{'/frozen'+key:sha for key,sha in unit.OBSERVED_SOURCES.items()},
        'tensor_layouts':{key:{'device':'npu:12'} for key in tensors}, 'scalar_values':{},
        'sfa_calls':[{'scale':0.0625}]}}}


def fixture():
    a,b,c=(unit.extract(frame()), unit.extract(frame(True),True),unit.extract(frame(sorted_arm=True)))
    return {'inputs':a['inputs'],'lengths':a['lengths'],'scale':a['scale'],
            'orders':{'original':a['inputs']['topk_indices'],'m32_order':b['inputs']['topk_indices'],
                      'sorted':c['inputs']['topk_indices']},
            'expected':{'original':a['expected'],'m32_order':b['expected'],'sorted':c['expected']}}


class Order(unittest.TestCase):
    def test_length_tensor_and_python_list_are_not_normalized_together(self):
        value=frame()
        tensor=unit.length(value,'actual_seq_lengths_query')
        self.assertEqual(tensor['kind'],'tensor')
        self.assertEqual(unit.runtime_length(tensor,'cpu').dtype,torch.int32)
        del value['observed']['tensors'][unit.PREFIX+'actual_seq_lengths_query']
        value['observed']['metadata']['scalar_values'][unit.PREFIX+'actual_seq_lengths_query.0']=1
        sequence=unit.length(value,'actual_seq_lengths_query')
        self.assertEqual(sequence['kind'],'python_list')
        self.assertIsInstance(unit.runtime_length(sequence,'cpu'),list)
        self.assertEqual(unit.runtime_length(sequence,'cpu'),[1])
        self.assertFalse(sequence['container_type_recorded'])

    def test_exact_frozen_ast_preserves_bf16_operator_arguments_and_list_identity(self):
        source=Path('/tmp/trt-device-op-sfa-token.py')
        self.assertEqual(unit.digest(source),unit.DEVICE_SHA)
        operation,sha=unit.method(source)
        self.assertEqual(len(sha),64)
        data=fixture(); x=data['inputs']; qlen=[1]; klen=torch.tensor([8206],dtype=torch.int32)
        expected=torch.zeros(1,4,512,dtype=torch.bfloat16)
        calls=[]
        def kernel(**kwargs):
            calls.append(kwargs)
            return (expected,)
        with patch.object(torch.ops._C_ascend,'npu_sparse_flash_attention',kernel,create=True):
            actual=operation(None,types.SimpleNamespace(scale=0.0625),x['ql_nope'],x['q_pe'],
                (x['kv_cache.0'],x['kv_cache.1']),x['topk_indices'],types.SimpleNamespace(block_table=x['block_table']),
                qlen,klen,block_table=x['block_table'])
        self.assertIs(actual,expected)
        self.assertIs(calls[0]['actual_seq_lengths_query'],qlen)
        self.assertIs(calls[0]['actual_seq_lengths_kv'],klen)
        self.assertIs(calls[0]['key'],calls[0]['value'])
        self.assertEqual(calls[0]['sparse_block_size'],1)
        self.assertEqual(calls[0]['layout_query'],'TND')
        self.assertEqual(calls[0]['layout_kv'],'PA_BSND')

    def test_96_calls_preserve_controls_and_reject_mutation_or_control_mismatch(self):
        data=fixture()
        lookup={unit.raw_sha(order):index for index,order in enumerate(data['orders'].values())}
        count=[]
        def kernel(cls,impl,q,pe,kv,indices,metadata,qlen,klen,*,block_table):
            count.append(unit.raw_sha(indices))
            return torch.full((1,4,512),lookup[unit.raw_sha(indices)],dtype=torch.bfloat16)
        with patch.object(torch,'npu',types.SimpleNamespace(synchronize=lambda:None),create=True):
            outputs,result=unit.replay(data,kernel,'cpu')
            self.assertEqual(len(count),96)
            self.assertTrue(result['controls_and_repeatability_passed'])
            self.assertTrue(result['order_sufficiency_met'])
            self.assertEqual(outputs['m32_order'].shape,(32,1,4,512))
            bad=copy.deepcopy(data); bad['expected']['sorted'].fill_(9)
            _,result=unit.replay(bad,kernel,'cpu')
            self.assertFalse(result['controls_and_repeatability_passed'])
            self.assertFalse(result['order_sufficiency_met'])
            def mutating(*args,**kwargs):
                value=kernel(*args,**kwargs)
                args[2][0,0,0]+=1
                return value
            _,result=unit.replay(data,mutating,'cpu')
            self.assertFalse(result['all_inputs_unchanged'])
            self.assertFalse(result['controls_and_repeatability_passed'])

    def test_admission_binds_actual_three_pt_chain_and_rejects_tampering(self):
        with tempfile.TemporaryDirectory() as tmp:
            directory=Path(tmp); (directory/'rank-12').mkdir()
            raw={}
            for name,value in [('original-serial.pt',frame()),('original-wide.pt',frame(True)),
                               ('sorted-serial.pt',frame(sorted_arm=True))]:
                path=directory/'rank-12'/name;torch.save(value,path);raw[name]=unit.digest(path)
            report={'rank':12,'status':'captured','reference_sha256':unit.REFERENCE_SHA,
                'teacher_sha256':'82d011962a288b30b777fc4964d5c96c6b9784cb13b97f509322f603b263b655',
                'checks':[{'passed':True}],'source_sha256':{'/frozen'+key:sha for key,sha in unit.SOURCES.items()},
                'trace_sha256':raw,'inputs':{'scope':'CPU fixture'},'checkpoint_sha256':{'scope':'CPU fixture'}}
            path=directory/'rank-12.json';path.write_text(json.dumps(report));report_sha=unit.digest(path)
            path=directory/'summary.json';path.write_text(json.dumps({'status':'captured',
                'all_rank_global_states_agree':True,'ranks':[{'rank':12,'report_sha256':report_sha}]}));summary_sha=unit.digest(path)
            with patch.multiple(unit,SUMMARY_SHA=summary_sha,REPORT_SHA=report_sha,RAW_SHA=raw):
                admitted=unit.admit(directory)
                self.assertEqual(admitted['swapped_flat_positions'],[1479,1531])
                self.assertTrue(unit.exact(admitted['inputs']['ql_nope'],frame()['observed']['tensors'][unit.PREFIX+'ql_nope']))
                with (directory/'rank-12/original-wide.pt').open('ab') as stream:stream.write(b'changed')
                with self.assertRaisesRegex(ValueError,'Frozen bytes differ'):
                    unit.admit(directory)

    def test_wrong_library_fails_before_any_npu_import(self):
        with tempfile.TemporaryDirectory() as tmp:
            directory=Path(tmp); library=directory/'wrong.so';library.write_bytes(b'wrong')
            output=directory/'output'
            argv=['sfa_order.py','--capture',str(directory),'--device-source','/tmp/trt-device-op-sfa-token.py',
                  '--library',str(library),'--output',str(output)]
            fake={**fixture(),'identities':{},'m32_lengths_not_replayed':{},'swapped_flat_positions':[1479,1531]}
            with patch.object(unit,'admit',return_value=fake),patch.object(sys,'argv',argv),redirect_stdout(io.StringIO()):
                self.assertEqual(unit.main(),1)
            report=json.loads((output/'report.json').read_text())
            self.assertFalse(report['npu_executed'])
            self.assertFalse(report['formal_precision_gate_passed'])
            self.assertNotIn('torch_npu',sys.modules)


if __name__=='__main__':unittest.main(verbosity=2)
